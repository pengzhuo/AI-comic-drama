"""项目成本报表：按上游中转站账单口径的消耗明细与制作时长。

数据来源是项目 ``data.db`` 里的四张用量表：

- ``video_request_usage`` / ``image_request_usage`` / ``audio_request_usage``
- ``llm_request_usage``

费用字段 ``cost_quota`` 由 ``novelvideo cost-reconcile`` 回填：默认 ``--source
local`` 用本地单价表按「用量 × 单价（实测优先）」计算，**不登录上游**；``--source
relay`` 取上游中转站（真正收钱的一方）的真实账单 quota，``--source gateway``
则取本地捏驿网关账单库。USD = ``cost_quota / QUOTA_PER_USD``（捏驿默认
500000）；中转站按 ¥ 展示，故同时给出 ``cny = usd * usd_cny_rate``。报告只读，
不触发任何网关调用；``cost_quota`` 为空的行归入 ``unattributed``。

时长口径：单条视频用应用侧 ``accepted_at``（提交网关、拿到 task id 的时刻）到
``completed_at``（观察到完成的时刻）；每集取该集视频的 ``min(accepted_at)`` 到
``max(completed_at)``。轮询间隔会给完成时刻带来秒级滞后，非端到端精确排队时长。
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Query

from novelvideo.api.auth import get_api_user
from novelvideo.api.deps import resolve_project_scope
from novelvideo.audio_request_usage import get_audio_request_usage_db_path
from novelvideo.config import QUOTA_PER_USD, REPORT_CURRENCY, USD_CNY_RATE
from novelvideo.gateway_cost_reconcile import (
    ReconcileReport,
    reconcile_local,
)
from novelvideo.image_request_usage import get_image_request_usage_db_path
from novelvideo.llm_request_usage import get_llm_request_usage_db_path
from novelvideo.video_request_usage import get_video_request_usage_db_path

logger = logging.getLogger("novelvideo.api.cost_report")

router = APIRouter()


@dataclass
class UsageRow:
    """One request row normalized across the four usage tables."""

    kind: str
    request_id: str
    model: str
    episode: int | None
    accepted_at: str | None
    completed_at: str | None
    quota: int | None
    status: str
    source: str = ""


@dataclass
class _Bucket:
    requests: int = 0
    quota: int = 0
    unattributed_requests: int = 0
    duration_seconds: float = 0.0
    started_at: str | None = None
    finished_at: str | None = None


@dataclass
class _Accumulator:
    video: list[UsageRow] = field(default_factory=list)
    image: list[UsageRow] = field(default_factory=list)
    audio: list[UsageRow] = field(default_factory=list)
    llm: list[UsageRow] = field(default_factory=list)


_KIND_LABELS = {
    "video": "视频",
    "image": "图片",
    "audio": "音频",
    "llm": "文本",
}


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?", (table,)
    ).fetchone()
    return row is not None


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in conn.execute(f"PRAGMA table_info({table})")}


def _read_rows(
    db_path: Path,
    *,
    kind: str,
    table: str,
    model_column: str,
    has_completed_at: bool,
) -> list[UsageRow]:
    if not db_path.is_file():
        return []
    rows: list[UsageRow] = []
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        if not _table_exists(conn, table):
            return []
        columns = _columns(conn, table)
        model_expr = model_column if model_column in columns else "''"
        episode_expr = "episode" if "episode" in columns else "NULL"
        quota_expr = "cost_quota" if "cost_quota" in columns else "NULL"
        source_expr = "cost_source" if "cost_source" in columns else "''"
        completed_expr = "completed_at" if has_completed_at else "NULL"
        status_expr = "status" if "status" in columns else "''"
        query = f"""
            SELECT request_id, {model_expr} AS model_name, {episode_expr} AS episode,
                   accepted_at, {completed_expr} AS completed_at,
                   {quota_expr} AS cost_quota, {source_expr} AS cost_source,
                   {status_expr} AS status
            FROM {table}
        """
        for row in conn.execute(query):
            quota_raw = row["cost_quota"]
            rows.append(
                UsageRow(
                    kind=kind,
                    request_id=str(row["request_id"] or ""),
                    model=str(row["model_name"] or ""),
                    episode=row["episode"] if isinstance(row["episode"], int) else None,
                    accepted_at=row["accepted_at"],
                    completed_at=row["completed_at"],
                    quota=int(quota_raw) if quota_raw is not None else None,
                    status=str(row["status"] or ""),
                    source=str(row["cost_source"] or ""),
                )
            )
    finally:
        conn.close()
    return rows


def _load_usage(project_output_dir: str | Path) -> _Accumulator:
    acc = _Accumulator()
    acc.video = _read_rows(
        get_video_request_usage_db_path(project_output_dir),
        kind="video",
        table="video_request_usage",
        model_column="model_name",
        has_completed_at=True,
    )
    acc.image = _read_rows(
        get_image_request_usage_db_path(project_output_dir),
        kind="image",
        table="image_request_usage",
        model_column="model_name",
        has_completed_at=False,
    )
    acc.audio = _read_rows(
        get_audio_request_usage_db_path(project_output_dir),
        kind="audio",
        table="audio_request_usage",
        model_column="model_name",
        has_completed_at=False,
    )
    acc.llm = _read_rows(
        get_llm_request_usage_db_path(project_output_dir),
        kind="llm",
        table="llm_request_usage",
        model_column="model",
        has_completed_at=False,
    )
    return acc


def _parse_ts(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _row_duration_seconds(row: UsageRow) -> float:
    if row.kind != "video":
        return 0.0
    started = _parse_ts(row.accepted_at)
    finished = _parse_ts(row.completed_at)
    if started is None or finished is None:
        return 0.0
    delta = (finished - started).total_seconds()
    return delta if delta > 0 else 0.0


def _merge_span(bucket: _Bucket, row: UsageRow) -> None:
    if row.kind != "video":
        return
    started = _parse_ts(row.accepted_at)
    finished = _parse_ts(row.completed_at)
    if started is not None:
        if bucket.started_at is None or str(started) < bucket.started_at:
            bucket.started_at = str(started)
    if finished is not None:
        if bucket.finished_at is None or str(finished) > bucket.finished_at:
            bucket.finished_at = str(finished)
    bucket.duration_seconds += _row_duration_seconds(row)


def _span_seconds(started_at: str | None, finished_at: str | None) -> float:
    started = _parse_ts(started_at)
    finished = _parse_ts(finished_at)
    if started is None or finished is None:
        return 0.0
    delta = (finished - started).total_seconds()
    return delta if delta > 0 else 0.0


def _as_quota_row(bucket: _Bucket) -> dict[str, Any]:
    span = _span_seconds(bucket.started_at, bucket.finished_at) if bucket.started_at else 0.0
    duration = span or bucket.duration_seconds
    usd = bucket.quota / QUOTA_PER_USD if QUOTA_PER_USD else 0.0
    return {
        "requests": bucket.requests,
        "unattributed_requests": bucket.unattributed_requests,
        "quota": bucket.quota,
        "usd": usd,
        "cny": usd * USD_CNY_RATE,
        "duration_seconds": round(duration, 3),
        "duration_hours": round(duration / 3600, 3) if duration else 0.0,
        "started_at": bucket.started_at,
        "finished_at": bucket.finished_at,
    }


def build_cost_report(
    *,
    project_output_dir: str | Path,
    episode: int | None = None,
) -> dict[str, Any]:
    acc = _load_usage(project_output_dir)
    all_rows: list[UsageRow] = [*acc.video, *acc.image, *acc.audio, *acc.llm]
    if episode is not None:
        all_rows = [row for row in all_rows if row.episode == episode]

    totals = _Bucket()
    by_kind: dict[str, _Bucket] = {}
    by_model: dict[tuple[str, str], _Bucket] = {}
    by_episode: dict[int | None, _Bucket] = {}
    by_day: dict[str, _Bucket] = {}
    by_source: dict[str, dict[str, int]] = {}
    unattributed: dict[str, int] = {kind: 0 for kind in _KIND_LABELS}

    for row in all_rows:
        kind_bucket = by_kind.setdefault(row.kind, _Bucket())
        model_bucket = by_model.setdefault((row.kind, row.model or "unknown"), _Bucket())
        episode_bucket = by_episode.setdefault(row.episode, _Bucket())
        day = str(row.accepted_at or "")[:10] or "unknown"
        day_bucket = by_day.setdefault(day, _Bucket())

        attributed = row.quota is not None
        source_key = row.source or ("unattributed" if not attributed else "unknown")
        source_stat = by_source.setdefault(source_key, {"requests": 0, "quota": 0})
        source_stat["requests"] += 1

        for bucket in (totals, kind_bucket, model_bucket, episode_bucket, day_bucket):
            bucket.requests += 1
            if attributed:
                bucket.quota += int(row.quota or 0)
            else:
                bucket.unattributed_requests += 1
            _merge_span(bucket, row)
        if attributed:
            source_stat["quota"] += int(row.quota or 0)
        else:
            unattributed[row.kind] = unattributed.get(row.kind, 0) + 1

    models = [
        {
            "kind": kind,
            "kind_label": _KIND_LABELS.get(kind, kind),
            "model": model,
            **_as_quota_row(bucket),
        }
        for (kind, model), bucket in by_model.items()
    ]
    models.sort(key=lambda item: (item["quota"], item["requests"]), reverse=True)

    episodes = [
        {"episode": episode_num, **_as_quota_row(bucket)}
        for episode_num, bucket in by_episode.items()
    ]
    episodes.sort(key=lambda item: (item["episode"] is None, item["episode"]))

    days = [
        {"date": day, **_as_quota_row(bucket)} for day, bucket in by_day.items()
    ]
    days.sort(key=lambda item: item["date"])

    kinds = [
        {"kind": kind, "kind_label": _KIND_LABELS.get(kind, kind), **_as_quota_row(bucket)}
        for kind, bucket in by_kind.items()
    ]
    kinds.sort(key=lambda item: item["quota"], reverse=True)

    sources = [
        {
            "source": source,
            "requests": stat["requests"],
            "quota": stat["quota"],
            "usd": stat["quota"] / QUOTA_PER_USD if QUOTA_PER_USD else 0.0,
            "cny": (stat["quota"] / QUOTA_PER_USD if QUOTA_PER_USD else 0.0)
            * USD_CNY_RATE,
        }
        for source, stat in by_source.items()
    ]
    sources.sort(key=lambda item: item["quota"], reverse=True)

    # 结算口径：全部命中的行来源。``local``=本地按用量×单价（实测优先，默认），
    # ``relay``=上游真账单，``gateway``=网关估值（偏高），多种来源=混口径。前端据此
    # 标注数字可信度。
    billed_sources = {
        source for source in by_source if source in {"relay", "gateway", "local"}
    }
    if billed_sources == {"local"}:
        cost_source = "local"
    elif billed_sources == {"relay"}:
        cost_source = "relay"
    elif billed_sources == {"gateway"}:
        cost_source = "gateway"
    elif billed_sources:
        cost_source = "mixed"
    else:
        cost_source = ""

    # 有未归因请求（含 unmatched 与被清空的行）时合计并不完整：金额口径本身可能
    # 仍是 relay，但报表要能标出「部分归因」，避免看起来像已经结清。
    unattributed_total = sum(unattributed.values())

    return {
        "generated_at": datetime.now().isoformat(),
        "episode": episode,
        "quota_per_usd": QUOTA_PER_USD,
        "currency": REPORT_CURRENCY,
        "usd_cny_rate": USD_CNY_RATE,
        "cost_source": cost_source,
        "partial": unattributed_total > 0,
        "sources": sources,
        "totals": _as_quota_row(totals),
        "by_kind": kinds,
        "by_model": models,
        "by_episode": episodes,
        "by_day": days,
        "unattributed": {
            "requests": unattributed_total,
            "by_kind": unattributed,
        },
    }


@router.get("/projects/{project}/cost-report")
async def get_project_cost_report(
    project: str,
    episode: int | None = Query(None, ge=1, description="只看某一集；缺省为全剧"),
    user: dict = Depends(get_api_user),
):
    """按上游账单口径返回项目消耗明细、每集时长与合计。"""
    resolution = await resolve_project_scope(project, user, required_role="viewer")
    data = build_cost_report(
        project_output_dir=resolution.output_dir,
        episode=episode,
    )
    data["project"] = {
        "id": resolution.ctx.project_id if resolution.ctx else project,
        "name": resolution.project_name,
        "owner": resolution.username,
    }
    return {"ok": True, "data": data}


#: 同一项目在这个窗口内不重复跑对账。一集有几条请求、前端可能连点「重新结算」，
#: 而每次对账都要读一遍网关账单库（量级 10^4 行），去抖掉重复调用即可。
RECONCILE_DEBOUNCE_SECONDS = 20.0
#: 一次对账（relay 优先会走几次上游 HTTP）最多花多久（秒）；超时就放弃这次、
#: 报表照常返回，避免用户点「重新结算」时长时间挂住。
RECONCILE_BUDGET_SECONDS = 90.0
_reconcile_gate = asyncio.Lock()
_reconcile_last_run: dict[str, float] = {}


def project_usage_db(state_dir: str | Path) -> Path:
    """项目用量库：``<state_dir>/data.db``（与 ``discover_project_dbs`` 同口径）。"""
    return Path(state_dir) / "data.db"


async def reconcile_project_usage(
    state_dir: str | Path,
    *,
    force: bool = False,
) -> tuple[ReconcileReport | None, bool]:
    """按本地单价表（实测优先）回填一个项目的 ``cost_quota``。

    返回 ``(report, skipped)``：``skipped=True`` 表示命中去抖窗口、这次没跑对账。
    不触网（不登录上游）、只写本项目 ``data.db``；失败以 ``report.errors`` 形式
    返回，不抛给请求方（费用报表本身仍然可读）。
    """
    db_path = project_usage_db(state_dir)
    key = str(db_path)
    async with _reconcile_gate:
        last = _reconcile_last_run.get(key, 0.0)
        if not force and (time.monotonic() - last) < RECONCILE_DEBOUNCE_SECONDS:
            return None, True
        _reconcile_last_run[key] = time.monotonic()
    try:
        report = await asyncio.wait_for(
            asyncio.to_thread(reconcile_local, project_db=db_path, apply=True),
            timeout=RECONCILE_BUDGET_SECONDS,
        )
    except asyncio.TimeoutError:
        logger.warning("cost reconcile timed out for %s", db_path)
        report = ReconcileReport(gateway_db=db_path, applied=False, source="local")
        report.errors.append(f"对账超时（>{RECONCILE_BUDGET_SECONDS:.0f}s）")
    except Exception as exc:  # noqa: BLE001 - 对账失败不影响报表可读
        logger.warning("cost reconcile failed for %s: %s", db_path, exc)
        report = ReconcileReport(gateway_db=db_path, applied=False)
        report.errors.append(str(exc))
    return report, False


@router.post("/projects/{project}/cost-report/reconcile")
async def reconcile_project_cost_report(
    project: str,
    episode: int | None = Query(None, ge=1, description="只看某一集；缺省为全剧"),
    force: bool = Query(False, description="忽略去抖窗口，强制重新对账"),
    user: dict = Depends(get_api_user),
):
    """按本地单价表对账并返回刷新后的报表。

    用「用量 × 单价（实测优先）」在本地计算，**不登录上游**，因此不受上游
    429/409 影响；``actual_rules`` 由真账反推，合计与真账同口径。每集合成完成后
    由 ``director_auto`` 自动触发一次（best-effort），前端「重新结算」按钮走同一条
    路径。只写本项目 ``data.db``；``unattributed`` 为未定价的请求，如实回报。
    """
    resolution = await resolve_project_scope(project, user, required_role="editor")
    report, skipped = await reconcile_project_usage(resolution.state_dir, force=force)
    data = build_cost_report(
        project_output_dir=resolution.output_dir,
        episode=episode,
    )
    data["project"] = {
        "id": resolution.ctx.project_id if resolution.ctx else project,
        "name": resolution.project_name,
        "owner": resolution.username,
    }
    data["reconcile"] = {
        "skipped": skipped,
        "applied": bool(report.applied) if report else False,
        "source": report.source if report else "gateway",
        "quota": report.quota if report else 0,
        "usd": report.usd if report else 0.0,
        "matched": sum(table.matched for item in report.projects for table in item.tables)
        if report
        else 0,
        "rows": sum(table.rows for item in report.projects for table in item.tables)
        if report
        else 0,
        "errors": list(report.errors) if report else [],
    }
    return {"ok": True, "data": data}
