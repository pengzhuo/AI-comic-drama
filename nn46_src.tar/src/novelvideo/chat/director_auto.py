"""Durable server-side coordinator for outer 捏导 episode auto mode."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sqlite3
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from novelvideo.chat import service as chat_service
from novelvideo.chat.live_events import broadcast_project_chat_event
from novelvideo.chat.moderation_prompt_repair import (
    PromptRepairOutcome,
    classify_moderation_text,
    moderation_repair_recovery_key,
    repair_prompt_for_moderation,
)
from novelvideo.pipeline_timing import record_event
from novelvideo.project_context import ProjectContext, resolve_project_context
from novelvideo.shared.billing_errors import (
    BILLING_RULE_NOT_CONFIGURED_CODE,
    BILLING_RULE_NOT_CONFIGURED_MESSAGE,
    FEATURE_BILLING_IDENTITY_INVALID_CODE,
    FEATURE_BILLING_IDENTITY_INVALID_MESSAGE,
    INSUFFICIENT_CREDITS_CODE,
    INSUFFICIENT_CREDITS_MESSAGE,
)
from novelvideo.shared.provider_errors import (
    CONTENT_MODERATION_FAILED_CODE,
    is_content_moderation_error,
)
from novelvideo.sqlite_pragmas import configure_sqlite_connection
from novelvideo.task_diagnostics import summarize_failure
from novelvideo.task_state import TaskState, get_task_manager


logger = logging.getLogger(__name__)

AUTO_TASK_TYPES = frozenset({
    "ingest_fast",
    "screenplay_preprocess",
    "script_process",
    "build_characters",
    "build_scenes",
    "build_props",
    "build_episodes",
    "identity_planner",
    "character_portrait",
    "identity_image",
    "content_rewriter",
    "script_writer",
    "literal_script_writer",
    "director_notes",
    "episode_scene_planner",
    "episode_prop_planner",
    "scene_reference_asset",
    "scene_pano_generation",
    "prop_reference_asset",
    "beat_video_prompt",
    "seedance2_prompt",
    "sketch_grid_generation",
    "sketch_generation",
    "sketch_regen",
    "grid_regenerate",
    "mainline_sketch_from_context",
    "mainline_frame_from_context",
    "ai_identity_detection",
    "global_optimize_video",
    "selected_regen",
    "render_plan",
    "system_voice_setup",
    "audio_generation",
    "indextts2_audio_generation",
    "audio_generation_indextts2",
    "single_video",
    "compose_episode",
})
ACTIVE_STATUSES = frozenset({"submitting", "queued", "pending", "running"})
TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled"})
#: Pause reason for "the next step needs a voice policy the user has not picked".
#: Also the tag a completed system-voice preparation looks for when it hands the
#: run back to the coordinator, so the two sites must share one string.
VOICE_POLICY_REQUIRED_ERROR = "缺少配音声线，且未选择声线策略（系统声线／自定义声线）"
POLL_SECONDS = 1.5
#: 重叠派发的节流：在已有任务在飞时，最多每这么久试一次「下一批就绪阶段」。
#: 太密只是白白重算 pipeline status，太疏又会留下成片的空转窗口。
OVERLAP_DISPATCH_SECONDS = 5.0
INITIAL_GRACE_SECONDS = 5.0
#: 续租要扛得住「一批任务把共享线程池/事件循环堵住几十秒」。续租走
#: ``asyncio.to_thread``，45s 窗口下只要一次续租迟到，心跳就会把 worker 取消掉，
#: run 便停在 ``running`` 而无人推进（任务行还在流，表面看不出问题）。
LEASE_SECONDS = 120.0
HEARTBEAT_SECONDS = 10.0
#: 连续多少次续租失败才判定租约真丢了（每次间隔 ``HEARTBEAT_SECONDS``）。
LEASE_RENEW_ATTEMPTS = 4
#: 认领租约的自旋上限（每次间隔 ``HEARTBEAT_SECONDS``，默认约 10 分钟）。只有在
#: 「另一个 owner 还握着有效租约」时才会一直转；设上限免得一个卡住的 owner 把
#: worker 永久挂在自旋里。
MAX_LEASE_CLAIM_ATTEMPTS = 60
#: 巡检间隔：发现「``status=running`` 但没有 worker 持有租约」就重新拉起。
REAPER_SECONDS = 30.0
#: 「身份图指定」闸门的服务端兜底宽限：这一档的语义是「不指定就由 AI 生成」，
#: 本来就没有必须人做主的决定。工作台开着时前端到点自己确认；浏览器不在时由
#: 巡检兜底，暂停超过这个时长就替客户把答案写下并继续，绝不把项目永久挂在
#: 「等一次人工点击」上（现场 ``系统标准格式版`` 就这么挂了 24 小时）。
IDENTITY_GATE_GRACE_SECONDS = 600.0
#: 硬暂停（非闸门）的服务端兜底宽限：工作台是「自动驾驶但方向盘在浏览器里」，
#: 浏览器一关，任何 ``paused`` 就永久停。巡检在这个宽限后替它续跑一次；只碰
#: :data:`PAUSE_KIND_RETRYABLE` 的暂停（闸门/阻塞/配置缺失/致命一律不碰）。
HARD_PAUSE_GRACE_SECONDS = 120.0
#: 服务端自动干预（兜底续跑 + 卡死重拉）的次数上限。只有 run **真正往前**
#: （换了一个 stage）或人工点击才清零，避免「暂停↔续跑」空转。
MAX_RECOVERY_ATTEMPTS = 5
#: ``status=running`` 但「真的没有进展」多久就判定卡死并重拉 worker（秒）。
#: 有相关任务在飞不算卡死（长渲染可以几十分钟没有 stage 变化）。
STALL_PROGRESS_SECONDS = 900.0

#: 暂停分类（``DirectorAutoRun.pause_kind``）。前端 / 内部端据此决定展示与动作，
#: 不再靠 ``last_error`` 子串匹配猜。
PAUSE_KIND_GATE = "gate"
PAUSE_KIND_VOICE = "voice_setup"
PAUSE_KIND_BLOCKED = "blocked"
PAUSE_KIND_NEEDS_CONFIG = "needs_config"
PAUSE_KIND_FATAL = "fatal"
PAUSE_KIND_RETRYABLE = "retryable"
PAUSE_KIND_NEEDS_HUMAN = "needs_human"
PAUSE_KIND_CONFIRM = "confirm"
#: 用户主动切换为手动 / 终止自动。绝不能被服务端兜底续跑唤醒。
PAUSE_KIND_STOPPED = "stopped"
#: 配置缺失暂停的稳定前缀（``_pause_gate`` 里那条）。
NEEDS_CONFIG_PREFIX = "项目配置缺失"
#: 阻塞型暂停的稳定标记：两种 reason 都含这个子串。
BLOCKED_PAUSE_MARKER = "自动续跑未产生"


def _pause_kind_for_reason(reason: str) -> str:
    """把人类可读的暂停原因归类成稳定的 ``pause_kind``。

    闸门/视图靠 ``last_error`` 的稳定标记（gate tag、配置缺失前缀、阻塞标记）
    识别，致命失败由调用方显式传 ``kind``（它的文字没有稳定前缀）。
    """

    text = str(reason or "")
    if (
        CHARACTER_IMAGES_GATE_TAG in text
        or IDENTITY_IMAGES_GATE_TAG in text
        or COST_ESTIMATE_GATE_TAG in text
    ):
        return PAUSE_KIND_GATE
    if text.strip() == VOICE_POLICY_REQUIRED_ERROR:
        return PAUSE_KIND_VOICE
    if text.startswith(NEEDS_CONFIG_PREFIX):
        return PAUSE_KIND_NEEDS_CONFIG
    if BLOCKED_PAUSE_MARKER in text:
        return PAUSE_KIND_BLOCKED
    if text.startswith("项目权限校验失败"):
        return PAUSE_KIND_FATAL
    if "手动模式" in text or "终止" in text:
        return PAUSE_KIND_STOPPED
    return PAUSE_KIND_RETRYABLE


_MISSING_CHARACTER_PORTRAIT_RE = re.compile(
    r"请先为角色[「“\"](?P<character>.+?)[」”\"]生成\s*Portrait（面部特写）"
)
#: Task error codes that mean "the task went silent" rather than "the task hit a
#: real error".  A stalled task is paused and offered to the user as a decision
#: instead of being treated as an unrecoverable failure.
STALL_ERROR_CODES = frozenset({"TASK_TIMEOUT", "TASK_STALLED"})
#: Stable marker prepended to a stall pause reason so the pending decision
#: survives a page reload (the reason is persisted on the durable run).
STALL_REASON_TAG = "[stall]"
#: Marker for the failure a granted retry is chasing. It keeps ``last_error``
#: pointing at the *cause* while the run is retrying, so a later pause on a
#: different path (e.g. no task in several turns) can still report it.
RETRY_REASON_PREFIX = "[retry "
#: Stable markers prepended to the two 「角色图片指定」gate pause reasons. The
#: reason is persisted on the durable run (``last_error``), so the marker is what
#: the 捏导 matches on to restore the inline upload card after a page reload —
#: the same convention ``STALL_REASON_TAG`` uses.
CHARACTER_IMAGES_GATE_TAG = "[character_images]"
IDENTITY_IMAGES_GATE_TAG = "[identity_images]"
#: 分镜写完之后、第一批花钱的图/视频之前的「制作成本预估」闸门。这是用户第一次
#: 能看到「这部片大概要花多少钱」的时刻，也是最该让他点头的时刻。
COST_ESTIMATE_GATE_TAG = "[cost_estimate]"
#: 触发预估闸门的 ``next_step``：分镜（``script``）已完成，下一步就要花钱。
COST_ESTIMATE_GATE_STEPS = frozenset({"asset_references", "sketch_generation"})
#: 一键成片 is about to render character portraits: this is the one chance for
#: the user to hand over their own 角色肖像 images before AI generation runs.
CHARACTER_IMAGES_REQUIRED_ERROR = (
    f"{CHARACTER_IMAGES_GATE_TAG} 请为角色指定肖像图片：可上传本地图片后继续，或直接跳过由 AI 生成"
)
#: 本集身份规划刚产出身份，但还有身份没有身份图：先让用户指定，或跳过。
IDENTITY_IMAGES_REQUIRED_ERROR = (
    f"{IDENTITY_IMAGES_GATE_TAG} 本集还有身份没有身份图：可上传本地图片后继续，或直接跳过由 AI 生成"
)
#: 分镜已写完，接下来就是图/视频/配音这些真正花钱的步骤：先把预估价摆出来。
COST_ESTIMATE_REQUIRED_ERROR = (
    f"{COST_ESTIMATE_GATE_TAG} 分镜已完成，请先确认本集制作成本预估，再开始生成画面与视频"
)
#: 闸门没答就有人从「继续」恢复：拒绝，并把原因直接交给客户。
#: 收费闸门的恢复只有一条合法路径——在报价卡上确认（那里会先预扣伴点）。见
#: :meth:`DirectorAutoCoordinator._cost_gate_blocks_resume`。
COST_ESTIMATE_RESUME_BLOCKED_ERROR = (
    "本集制作成本尚未确认：请先在客户工作台点「确认报价，继续制作」（会预扣伴点）后再继续"
)
#: 自动兜底续跑撞到上限：run 已被设为 ``needs_human``，等人工判断（别再自动重试）。
AUTO_RECOVERY_EXHAUSTED_ERROR = "自动恢复次数已用尽，请人工检查后继续"
#: Meta/bridge tools the agent uses to inspect its tool surface instead of
#: operating on the project. Introspection must never count as a write: the
#: bridge echoes the *described* tool name, so a turn that only described a
#: generator used to look like it had already started the task.
_META_TOOL_NAMES = frozenset(
    {
        "tool_call",
        "tool_describe",
        "tool_search",
        "skills_list",
        "skill_view",
        "dramaclaw_tool_call",
        "dramaclaw_tool_describe",
        "dramaclaw_tool_search",
    }
)
#: DramaClaw tools that only read state; they never enqueue a generation task.
_READ_TOOL_PREFIXES = (
    "dramaclaw_get",
    "dramaclaw_list",
    "dramaclaw_pipeline_status",
)
#: Consecutive continuations without a new task that are tolerated before the
#: durable run pauses and hands the decision back to the user.
MAX_TASKLESS_CONTINUATIONS = 3
#: Bounded auto-retry budget for one mainline stage. A transient task failure no
#: longer pauses the whole run: the coordinator re-drives the same stage up to
#: this many times and only then hands the decision back to the user. The budget
#: is per stage (keyed on the task type the run is driving) and resets as soon as
#: that stage makes progress, so unrelated later stages keep their own budget.
MAX_STAGE_ATTEMPTS = 3
#: Backoff before retry N (1-based). Indexing beyond the tuple repeats the last
#: value, so a smaller budget than the tuple length stays cheap to reason about.
STAGE_RETRY_BACKOFF_SECONDS = (10.0, 30.0, 60.0)
#: ``DIRECTOR_AUTO_STAGE_RETRY=0`` restores the previous pause-on-first-failure
#: behaviour for an operator without a code change.
STAGE_RETRY_ENV = "DIRECTOR_AUTO_STAGE_RETRY"
#: Error codes where an automatic retry is pointless or unsafe: retrying cannot
#: create credits, grant a missing permission, or cross a denied egress.
_FATAL_ERROR_CODES = frozenset(
    {
        INSUFFICIENT_CREDITS_CODE,
        BILLING_RULE_NOT_CONFIGURED_CODE,
        FEATURE_BILLING_IDENTITY_INVALID_CODE,
        "FEATURE_SETTLEMENT_RESOLUTION_FAILED",
        "ORG_EGRESS_DENIED",
        "ORG_SERVICE_EGRESS_DENIED",
        "EGRESS_OPERATION_REPLAYED",
        # The request is rebuilt deterministically on every attempt, so a
        # configured-window overflow cannot resolve itself by retrying; the
        # per-stage workflow already spent its own split/retry budget first.
        "MODEL_CONTEXT_BUDGET_EXCEEDED",
    }
)
_FATAL_ERROR_LABELS = {
    INSUFFICIENT_CREDITS_CODE: INSUFFICIENT_CREDITS_MESSAGE,
    BILLING_RULE_NOT_CONFIGURED_CODE: BILLING_RULE_NOT_CONFIGURED_MESSAGE,
    FEATURE_BILLING_IDENTITY_INVALID_CODE: FEATURE_BILLING_IDENTITY_INVALID_MESSAGE,
    "MODEL_CONTEXT_BUDGET_EXCEEDED": "模型上下文预算不足（自动拆分与重试已用尽）",
}
#: Free-text fallback for failures that carry no structured code. Kept narrow on
#: purpose: a false positive only costs the retry we would not have spent, but a
#: false negative retries a doomed request three times.
_FATAL_ERROR_TEXT_RE = re.compile(
    r"insufficient credits|unauthorized|forbidden|积分不足|计费规则未配置|"
    r"无权限|未授权|egress is denied|EGRESS_DENIED",
    re.IGNORECASE,
)


def _stage_retry_enabled() -> bool:
    """Whether the bounded auto-retry is active (operator kill switch)."""

    raw = os.environ.get(STAGE_RETRY_ENV, "1").strip().lower()
    return raw not in {"0", "off", "false", "no"}


def _stage_retry_delay(attempt: int) -> float:
    """Seconds to wait before retry ``attempt`` (1-based)."""

    if not STAGE_RETRY_BACKOFF_SECONDS:
        return 0.0
    index = min(max(int(attempt), 1), len(STAGE_RETRY_BACKOFF_SECONDS)) - 1
    return float(STAGE_RETRY_BACKOFF_SECONDS[index])


def _is_fatal_failure(task: TaskState) -> str | None:
    """Return a human-facing reason when retrying this failure cannot help.

    Billing, egress and user cancellation are terminal by construction: the same
    request will fail again, so spending the retry budget only delays the
    decision the user has to make.
    """

    code = _task_error_code(task)
    if code in _FATAL_ERROR_CODES:
        label = _FATAL_ERROR_LABELS.get(code, code)
        detail = str(task.error or "").strip()
        if detail and label not in detail:
            return f"{label}（{detail[:160]}）"
        return label
    if task.status == "cancelled":
        return "任务已取消"
    text = f"{task.error or ''} {task.current_task or ''}"[:600]
    if _FATAL_ERROR_TEXT_RE.search(text):
        return "上游拒绝且重试无法解决，请检查账号额度或权限"
    return None


#: 审核补救允许 composer 花多久（秒）。composer 自带重试，这里只兜住「卡死不返回」。
MODERATION_REPAIR_TIMEOUT_SECONDS = 300.0
#: 一次 agent 续跑最多允许多久（秒）。后端自带 300s idle / 1800s total，这里再兜一层
#: 显式总超时：一旦超时就当「可重试失败」暂停，交给服务端兜底续跑/人工，绝不让一次
#: 挂死的 turn 把 run 永久留在 ``running``（心跳还在续租，reaper 看不出来）。
AGENT_CONTINUE_TIMEOUT_SECONDS = 1800.0
#: 成片后成本对账（relay 优先）允许花多久（秒）。超出就放弃这次自动对账，
#: 报表按钮/结算路径仍能补上；绝不让上游网络抖动拖住成片流程。
EPISODE_COST_RECONCILE_TIMEOUT_SECONDS = 180.0


def _task_moderation_text(task: TaskState) -> str:
    """参与审核分档判断的文本：归一后的错误 + 上游原文（若有）。"""

    parts = [str(getattr(task, "error", "") or "")]
    metadata = getattr(task, "metadata", None)
    if isinstance(metadata, dict):
        for key in ("message", "provider_error"):
            value = metadata.get(key)
            if value:
                parts.append(str(value))
    result = getattr(task, "result", None)
    if isinstance(result, dict):
        nested = result.get("task_metadata")
        if isinstance(nested, dict):
            for key in ("message", "provider_error"):
                value = nested.get(key)
                if value:
                    parts.append(str(value))
    return " ".join(part for part in parts if part).strip()[:2000]


def _moderation_kind(task: TaskState) -> str | None:
    """命中内容审核类失败时返回分档（见 moderation_prompt_repair），否则 None。

    内容审核失败既不该走通用重试（同一套参数再投一次必然再被拒），也不该像计费
    那样直接停下——中间还留着一手「改写提示词后再试」。分档决定用哪一手。
    """

    text = _task_moderation_text(task)
    code = _task_error_code(task)
    if code != CONTENT_MODERATION_FAILED_CODE and not is_content_moderation_error(
        message=text
    ):
        return None
    return classify_moderation_text(text)


def _moderation_repair_target(task: TaskState, run: DirectorAutoRun) -> tuple[int, int] | None:
    """审核补救要改哪一镜的提示词；定位不到具体镜号就返回 None。

    只有带 beat_num 的任务（单镜视频这类）能精确到一镜。批量 stage 的失败报文里
    没有「是哪一镜被拒」的信息，宁可不猜——调用方会直接暂停，而不是拿原样参数重投。
    """

    beat_num = getattr(task, "beat_num", None)
    try:
        beat_num = int(beat_num) if beat_num is not None else 0
    except (TypeError, ValueError):
        beat_num = 0
    episode = int(getattr(task, "episode", 0) or 0) or int(run.episode or 0)
    if beat_num > 0 and episode > 0:
        return episode, beat_num
    return None


def _stage_key_for(task: TaskState | None, run: DirectorAutoRun) -> str:
    """Budget key of the stage the run is currently driving."""

    task_type = str(getattr(task, "task_type", "") or "")
    if task_type:
        return task_type
    return run.stage_key or "unknown"


def _fallback_kind(stage_key: str) -> str:
    """该 stage 失败时的本地降级方式。

    ``video``：单镜视频 → 用首帧合成静帧/缓推短片；
    ``frame``：首帧渲染 → 用已有草图顶替首帧；
    ``none``：没有可靠的本地兜底（如草图本身），只能登记后跳过。
    """

    key = (stage_key or "").lower()
    if "video" in key:
        return "video"
    if key in {"selected_regen", "render", "first_frame"} or "regen" in key:
        return "frame"
    return "none"


def _film_pack_delivery_block() -> str:
    """成片合成/交付指令附带的流程包段落（第 06 份：衔接声音与成片验收）。

    主线与画布的合成本身是纯音视频编排，没有发往模型的提示词，所以第 06 份
    只能沿合成周边的 agent 指令送达：这里接管「成片已完成，去展示并收口」这一步。
    任何异常都退回空串，注入只是增强，绝不打断自动成片。
    """

    try:
        from novelvideo.skills.ai_film_process import pack_block

        return pack_block("compose_delivery")
    except Exception:  # noqa: BLE001 - 注入只是增强，不能影响自动成片
        return ""


def _retry_pause_detail(run: DirectorAutoRun) -> str:
    """The failure that armed the retry, for a pause reached on another path."""

    if not run.last_error.startswith(RETRY_REASON_PREFIX):
        return ""
    return run.last_error.split("] ", 1)[-1].strip()


def _pause_reason_display(reason: str) -> str:
    """Human copy for the chat timeline: the gate markers are UI plumbing.

    The marker has to stay on ``last_error`` (that is what survives a reload and
    what the 捏导 matches), but the narration line the user reads should not show
    it.
    """

    text = str(reason or "")
    for tag in (CHARACTER_IMAGES_GATE_TAG, IDENTITY_IMAGES_GATE_TAG, COST_ESTIMATE_GATE_TAG):
        if text.startswith(tag):
            return text[len(tag) :].strip()
    return text


def _event_tool_name(event: dict[str, Any]) -> str:
    """Effective tool name of a lifecycle event (``server.tool`` collapsed)."""

    return str(event.get("name") or "").rsplit(".", 1)[-1].strip()


def _event_inner_tool_name(event: dict[str, Any]) -> str:
    """Inner tool name carried by a ``tool_call`` bridge invocation."""

    payload = event.get("input")
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except (TypeError, ValueError):
            return ""
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("name") or "").strip()


def _event_is_write_tool(event: dict[str, Any]) -> bool:
    """Whether a lifecycle event is a real DramaClaw write/generation call.

    ``tool_describe``/``tool_search`` only inspect the tool surface, while
    ``tool_call`` is the bridge wrapper around a real invocation — only the
    latter is unwrapped to its inner tool name. Everything else keeps the
    original rule: a ``dramaclaw_`` tool that is not a read-only lookup.
    """

    name = _event_tool_name(event)
    if not name:
        return False
    if name in _META_TOOL_NAMES:
        if not name.endswith("tool_call"):
            return False
        name = _event_inner_tool_name(event)
    if not name.startswith("dramaclaw_"):
        return False
    return not name.startswith(_READ_TOOL_PREFIXES)


def _event_failure_detail(event: dict[str, Any]) -> str:
    """Best-effort ``status_code``/error text from a tool event payload."""

    def scan(value: Any, depth: int = 0) -> str:
        if depth > 4:
            return ""
        if isinstance(value, dict):
            if value.get("ok") is False or value.get("error"):
                code = value.get("status_code") or value.get("code")
                message = (
                    value.get("error") or value.get("detail") or value.get("message")
                )
                if isinstance(message, dict):
                    message = message.get("detail") or message.get("message")
                parts = [str(part) for part in (code, message) if part]
                if parts:
                    return " ".join(parts)
            for nested in value.values():
                found = scan(nested, depth + 1)
                if found:
                    return found
        elif isinstance(value, (list, tuple)):
            for nested in value:
                found = scan(nested, depth + 1)
                if found:
                    return found
        elif isinstance(value, str) and value.strip()[:1] in {"{", "["}:
            try:
                return scan(json.loads(value), depth + 1)
            except (TypeError, ValueError):
                return ""
        return ""

    return scan(
        {
            "error": event.get("error"),
            "structured": event.get("structured"),
            "output": event.get("output"),
        }
    )


def _task_error_code(task) -> str:
    metadata = getattr(task, "metadata", None)
    if isinstance(metadata, dict) and metadata.get("error_code"):
        return str(metadata["error_code"])
    result = getattr(task, "result", None)
    if isinstance(result, dict):
        nested = result.get("task_metadata")
        if isinstance(nested, dict) and nested.get("error_code"):
            return str(nested["error_code"])
    return ""


def _task_is_stalled(task) -> bool:
    return _task_error_code(task) in STALL_ERROR_CODES


def _task_failure_payload(task) -> dict | None:
    """Structured failure diagnostics attached by the task runner, if any."""

    metadata = getattr(task, "metadata", None)
    if isinstance(metadata, dict) and isinstance(metadata.get("failure"), dict):
        return metadata["failure"]
    result = getattr(task, "result", None)
    if isinstance(result, dict):
        nested = result.get("task_metadata")
        if isinstance(nested, dict) and isinstance(nested.get("failure"), dict):
            return nested["failure"]
    return None


def _failure_reason_with_detail(task, reason: str) -> str:
    """Append the operation/model summary to a human-facing failure reason."""

    detail = summarize_failure(_task_failure_payload(task))
    if not detail:
        return reason
    base = (reason or "").strip()
    if detail in base:
        return base
    return f"{base}（{detail}）" if base else detail


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _timestamp(value: str | None) -> float:
    try:
        return datetime.fromisoformat(str(value or "").replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError):
        return 0.0


def _state_root() -> Path:
    configured = os.environ.get("NOVELVIDEO_STATE_DIR", "").strip()
    if configured:
        return Path(configured).expanduser()
    return Path(__file__).resolve().parents[3] / "state"


def _serialize_context(ctx: ProjectContext) -> str:
    data = asdict(ctx)
    for key in ("output_dir", "state_dir", "runtime_dir"):
        data[key] = str(data[key])
    data["requester_principals"] = [list(item) for item in ctx.requester_principals]
    return json.dumps(data, ensure_ascii=False)


def _deserialize_context(raw: str) -> ProjectContext:
    data = json.loads(raw)
    for key in ("output_dir", "state_dir", "runtime_dir"):
        data[key] = Path(data[key])
    data["requester_principals"] = tuple(tuple(item) for item in data["requester_principals"])
    return ProjectContext(**data)


@dataclass(frozen=True)
class DirectorAutoRun:
    run_id: str
    username: str
    project_id: str
    episode: int
    status: str
    activated_at: str
    updated_at: str
    context_json: str
    baseline_task_ids: tuple[str, ...]
    handled_task_ids: tuple[str, ...]
    recovery_keys: tuple[str, ...] = ()
    voice_policy: str = ""
    last_error: str = ""
    scope: str = "episode"
    target_episodes: int = 0
    config_json: str = "{}"
    driver: str = "agent"
    #: Stage the coordinator is currently driving and how many automatic retries
    #: it has already spent on it. ``next_attempt_at`` is the epoch gate that
    #: keeps a retry from hammering a provider that just failed.
    stage_key: str = ""
    stage_attempts: int = 0
    next_attempt_at: float = 0.0
    #: Shots the coordinator gave up on for this run (upstream moderation, or
    #: retries exhausted). Each entry is ``{episode, beat, stage, code, reason,
    #: degraded, at}``. The coordinator skips them so the episode can still
    #: finish instead of stalling on one shot; the client surfaces them as a
    #: loud, per-shot error the user can act on (fix the prompt and redo).
    blocked_shots: tuple[dict[str, Any], ...] = ()
    #: 结构化暂停分类（见 :data:`PAUSE_KIND_GATE` 等）。客户端据此决定展示与动作，
    #: 不再靠 ``last_error`` 子串匹配；``""`` 表示当前没有暂停。
    pause_kind: str = ""
    #: 服务端自动干预（兜底续跑 + 卡死重拉）尚未换来真正进展的次数。只有换了一个
    #: stage（真正往前）或人工点击才清零，见 :data:`MAX_RECOVERY_ATTEMPTS`。
    recovery_attempts: int = 0

    @property
    def context(self) -> ProjectContext:
        return _deserialize_context(self.context_json)

    @property
    def is_project_scope(self) -> bool:
        return self.scope == "project"

    @property
    def is_deterministic(self) -> bool:
        return self.driver == "deterministic"


class DirectorAutoStore:
    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = db_path or (_state_root() / "director_auto.db")

    def _connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        configure_sqlite_connection(conn)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS director_auto_runs (
              run_id TEXT PRIMARY KEY,
              username TEXT NOT NULL,
              project_id TEXT NOT NULL,
              episode INTEGER NOT NULL,
              status TEXT NOT NULL,
              activated_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              context_json TEXT NOT NULL,
              baseline_task_ids_json TEXT NOT NULL,
              handled_task_ids_json TEXT NOT NULL,
              recovery_keys_json TEXT NOT NULL DEFAULT '[]',
              voice_policy TEXT NOT NULL DEFAULT '',
              last_error TEXT NOT NULL DEFAULT '',
              scope TEXT NOT NULL DEFAULT 'episode',
              target_episodes INTEGER NOT NULL DEFAULT 0,
              config_json TEXT NOT NULL DEFAULT '{}',
              driver TEXT NOT NULL DEFAULT 'agent',
              stage_key TEXT NOT NULL DEFAULT '',
              stage_attempts INTEGER NOT NULL DEFAULT 0,
              next_attempt_at REAL NOT NULL DEFAULT 0,
              blocked_shots_json TEXT NOT NULL DEFAULT '[]',
              pause_kind TEXT NOT NULL DEFAULT '',
              recovery_attempts INTEGER NOT NULL DEFAULT 0,
              owner_token TEXT NOT NULL DEFAULT '',
              lease_expires_at REAL NOT NULL DEFAULT 0,
              UNIQUE(username, project_id)
            )
            """
        )
        columns = {
            str(row["name"])
            for row in conn.execute("PRAGMA table_info(director_auto_runs)").fetchall()
        }
        if "recovery_keys_json" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN recovery_keys_json TEXT NOT NULL DEFAULT '[]'"
            )
        if "voice_policy" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN voice_policy TEXT NOT NULL DEFAULT ''"
            )
        if "owner_token" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN owner_token TEXT NOT NULL DEFAULT ''"
            )
        if "lease_expires_at" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN lease_expires_at REAL NOT NULL DEFAULT 0"
            )
        if "scope" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN scope TEXT NOT NULL DEFAULT 'episode'"
            )
        if "target_episodes" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN target_episodes INTEGER NOT NULL DEFAULT 0"
            )
        if "config_json" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN config_json TEXT NOT NULL DEFAULT '{}'"
            )
        if "driver" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN driver TEXT NOT NULL DEFAULT 'agent'"
            )
        if "stage_key" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN stage_key TEXT NOT NULL DEFAULT ''"
            )
        if "stage_attempts" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN stage_attempts INTEGER NOT NULL DEFAULT 0"
            )
        if "next_attempt_at" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN next_attempt_at REAL NOT NULL DEFAULT 0"
            )
        if "blocked_shots_json" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN blocked_shots_json TEXT NOT NULL DEFAULT '[]'"
            )
        if "pause_kind" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN pause_kind TEXT NOT NULL DEFAULT ''"
            )
        if "recovery_attempts" not in columns:
            conn.execute(
                "ALTER TABLE director_auto_runs "
                "ADD COLUMN recovery_attempts INTEGER NOT NULL DEFAULT 0"
            )
        conn.commit()
        return conn

    @staticmethod
    def _row(row: sqlite3.Row | None) -> DirectorAutoRun | None:
        if row is None:
            return None
        return DirectorAutoRun(
            run_id=str(row["run_id"]),
            username=str(row["username"]),
            project_id=str(row["project_id"]),
            episode=int(row["episode"]),
            status=str(row["status"]),
            activated_at=str(row["activated_at"]),
            updated_at=str(row["updated_at"]),
            context_json=str(row["context_json"]),
            baseline_task_ids=tuple(json.loads(row["baseline_task_ids_json"] or "[]")),
            handled_task_ids=tuple(json.loads(row["handled_task_ids_json"] or "[]")),
            recovery_keys=tuple(json.loads(row["recovery_keys_json"] or "[]")),
            voice_policy=str(row["voice_policy"] or ""),
            last_error=str(row["last_error"] or ""),
            scope=str(row["scope"] or "episode"),
            target_episodes=int(row["target_episodes"] or 0),
            config_json=str(row["config_json"] or "{}"),
            driver=str(row["driver"] or "agent"),
            stage_key=str(row["stage_key"] or ""),
            stage_attempts=int(row["stage_attempts"] or 0),
            next_attempt_at=float(row["next_attempt_at"] or 0.0),
            blocked_shots=tuple(json.loads(row["blocked_shots_json"] or "[]")),
            pause_kind=str(row["pause_kind"] or ""),
            recovery_attempts=int(row["recovery_attempts"] or 0),
        )

    def upsert(self, run: DirectorAutoRun) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO director_auto_runs(
                  run_id, username, project_id, episode, status, activated_at,
                  updated_at, context_json, baseline_task_ids_json,
                  handled_task_ids_json, recovery_keys_json, voice_policy, last_error,
                  scope, target_episodes, config_json, driver,
                  stage_key, stage_attempts, next_attempt_at, blocked_shots_json,
                  pause_kind, recovery_attempts
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(username, project_id) DO UPDATE SET
                  run_id=excluded.run_id,
                  episode=excluded.episode,
                  status=excluded.status,
                  activated_at=excluded.activated_at,
                  updated_at=excluded.updated_at,
                  context_json=excluded.context_json,
                  baseline_task_ids_json=excluded.baseline_task_ids_json,
                  handled_task_ids_json=excluded.handled_task_ids_json,
                  recovery_keys_json=excluded.recovery_keys_json,
                  voice_policy=excluded.voice_policy,
                  last_error=excluded.last_error,
                  scope=excluded.scope,
                  target_episodes=excluded.target_episodes,
                  config_json=excluded.config_json,
                  driver=excluded.driver,
                  stage_key=excluded.stage_key,
                  stage_attempts=excluded.stage_attempts,
                  next_attempt_at=excluded.next_attempt_at,
                  blocked_shots_json=excluded.blocked_shots_json,
                  pause_kind=excluded.pause_kind,
                  recovery_attempts=excluded.recovery_attempts,
                  owner_token=CASE
                    WHEN director_auto_runs.run_id != excluded.run_id THEN ''
                    ELSE director_auto_runs.owner_token
                  END,
                  lease_expires_at=CASE
                    WHEN director_auto_runs.run_id != excluded.run_id THEN 0
                    ELSE director_auto_runs.lease_expires_at
                  END
                """,
                (
                    run.run_id,
                    run.username,
                    run.project_id,
                    run.episode,
                    run.status,
                    run.activated_at,
                    run.updated_at,
                    run.context_json,
                    json.dumps(list(run.baseline_task_ids)),
                    json.dumps(list(run.handled_task_ids)),
                    json.dumps(list(run.recovery_keys)),
                    run.voice_policy,
                    run.last_error,
                    run.scope,
                    int(run.target_episodes or 0),
                    run.config_json or "{}",
                    run.driver,
                    run.stage_key,
                    int(run.stage_attempts or 0),
                    float(run.next_attempt_at or 0.0),
                    json.dumps(list(run.blocked_shots)),
                    run.pause_kind or "",
                    int(run.recovery_attempts or 0),
                ),
            )

    def get(self, username: str, project_id: str) -> DirectorAutoRun | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM director_auto_runs WHERE username=? AND project_id=?",
                (username, project_id),
            ).fetchone()
        return self._row(row)

    def get_by_project(self, project_id: str) -> DirectorAutoRun | None:
        """项目下最近更新的一条 run，不管归属者是谁。

        闸门回答与「继续」必须作用在**项目自己的 run** 上：答案要落进 ``_pause_gate``
        读的那份配置、恢复要唤醒同一个 run。之前按请求者 username 查，内部端
        （username ``local``）既把答案写进了 ``state/local/<project_id>/``，又恢复失败并
        静默返回 200，客户的项目就永远卡在闸门上了。
        """

        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM director_auto_runs WHERE project_id=? "
                "ORDER BY updated_at DESC LIMIT 1",
                (project_id,),
            ).fetchone()
        return self._row(row)

    def active(self) -> list[DirectorAutoRun]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM director_auto_runs WHERE status='running'"
            ).fetchall()
        return [run for row in rows if (run := self._row(row)) is not None]

    def running_without_lease(self, now: float) -> list[DirectorAutoRun]:
        """运行中但没人驱动的 run：租约空闲或已过期。"""

        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM director_auto_runs
                WHERE status='running'
                  AND (owner_token='' OR lease_expires_at<=?)
                """,
                (float(now),),
            ).fetchall()
        return [run for row in rows if (run := self._row(row)) is not None]

    def paused_identity_gate_before(self, cutoff: str) -> list[DirectorAutoRun]:
        """暂停在「身份图指定」闸门、且已经等超过 ``cutoff`` 的 run。

        停下来的 run 不再被 worker 推进，所以 ``updated_at`` 就是它写进暂停原因
        的那一刻；此后没人碰过就一直是它，正好当「停在这个闸门上多久了」的计时钟。
        ``last_error`` 里带 ``[identity_images]`` 是闸门的稳定标记（见
        :data:`IDENTITY_IMAGES_GATE_TAG`），与前端识别闸门用的是同一份约定。
        """

        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM director_auto_runs "
                "WHERE status='paused' AND last_error LIKE ? AND updated_at<=?",
                (f"{IDENTITY_IMAGES_GATE_TAG}%", str(cutoff)),
            ).fetchall()
        return [run for row in rows if (run := self._row(row)) is not None]

    def paused_kind_before(self, kind: str, cutoff: str) -> list[DirectorAutoRun]:
        """暂停在指定 ``pause_kind``、且已超过 ``cutoff`` 的 run。

        用于服务端兜底续跑：只选 ``retryable``（闸门 / 阻塞 / 配置缺失 / 致命由
        各自的人工入口处理）。``updated_at`` 就是它写进暂停原因的那一刻，正好当
        「停在这里多久了」的计时钟。
        """

        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM director_auto_runs "
                "WHERE status='paused' AND pause_kind=? AND updated_at<=?",
                (str(kind), str(cutoff)),
            ).fetchall()
        return [run for row in rows if (run := self._row(row)) is not None]

    def running_all(self, before: str) -> list[DirectorAutoRun]:
        """``status=running`` 且 ``updated_at`` 早于 ``before`` 的 run（卡死检测）。"""

        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM director_auto_runs "
                "WHERE status='running' AND updated_at<=?",
                (str(before),),
            ).fetchall()
        return [run for row in rows if (run := self._row(row)) is not None]


    def claim_lease(
        self,
        run_id: str,
        owner_token: str,
        *,
        lease_seconds: float = LEASE_SECONDS,
        now: float | None = None,
    ) -> bool:
        """Atomically claim one running coordinator lease across API processes."""

        current = datetime.now(timezone.utc).timestamp() if now is None else float(now)
        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE director_auto_runs
                SET owner_token=?, lease_expires_at=?
                WHERE run_id=? AND status='running'
                  AND (owner_token='' OR owner_token=? OR lease_expires_at<=?)
                """,
                (owner_token, current + lease_seconds, run_id, owner_token, current),
            )
            conn.commit()
            return cursor.rowcount == 1

    def renew_lease(
        self,
        run_id: str,
        owner_token: str,
        *,
        lease_seconds: float = LEASE_SECONDS,
        now: float | None = None,
    ) -> bool:
        current = datetime.now(timezone.utc).timestamp() if now is None else float(now)
        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE director_auto_runs
                SET lease_expires_at=?
                WHERE run_id=? AND status='running' AND owner_token=?
                  AND lease_expires_at>?
                """,
                (current + lease_seconds, run_id, owner_token, current),
            )
            conn.commit()
            return cursor.rowcount == 1

    def owns_lease(
        self,
        run_id: str,
        owner_token: str,
        *,
        now: float | None = None,
    ) -> bool:
        current = datetime.now(timezone.utc).timestamp() if now is None else float(now)
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT 1 FROM director_auto_runs
                WHERE run_id=? AND status='running' AND owner_token=?
                  AND lease_expires_at>?
                """,
                (run_id, owner_token, current),
            ).fetchone()
        return row is not None

    def update_if_owned(
        self,
        run: DirectorAutoRun,
        owner_token: str,
        *,
        now: float | None = None,
    ) -> bool:
        """Persist a worker transition only while its lease is still current."""

        current = datetime.now(timezone.utc).timestamp() if now is None else float(now)
        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE director_auto_runs
                SET episode=?, status=?, activated_at=?, updated_at=?, context_json=?,
                    baseline_task_ids_json=?, handled_task_ids_json=?,
                    recovery_keys_json=?, voice_policy=?, last_error=?,
                    scope=?, target_episodes=?, config_json=?, driver=?,
                    stage_key=?, stage_attempts=?, next_attempt_at=?,
                    blocked_shots_json=?, pause_kind=?, recovery_attempts=?
                WHERE run_id=? AND status='running' AND owner_token=?
                  AND lease_expires_at>?
                """,
                (
                    run.episode,
                    run.status,
                    run.activated_at,
                    run.updated_at,
                    run.context_json,
                    json.dumps(list(run.baseline_task_ids)),
                    json.dumps(list(run.handled_task_ids)),
                    json.dumps(list(run.recovery_keys)),
                    run.voice_policy,
                    run.last_error,
                    run.scope,
                    int(run.target_episodes or 0),
                    run.config_json or "{}",
                    run.driver,
                    run.stage_key,
                    int(run.stage_attempts or 0),
                    float(run.next_attempt_at or 0.0),
                    json.dumps(list(run.blocked_shots)),
                    run.pause_kind or "",
                    int(run.recovery_attempts or 0),
                    run.run_id,
                    owner_token,
                    current,
                ),
            )
            conn.commit()
            return cursor.rowcount == 1

    def release_lease(self, run_id: str, owner_token: str) -> bool:
        """Release only the caller's lease; stale workers cannot release a new owner."""

        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE director_auto_runs
                SET owner_token='', lease_expires_at=0
                WHERE run_id=? AND owner_token=?
                """,
                (run_id, owner_token),
            )
            conn.commit()
            return cursor.rowcount == 1

    def force_release_lease(self, run_id: str) -> None:
        """User/control-plane path for intentionally stopping any current owner."""

        with self._connect() as conn:
            conn.execute(
                """
                UPDATE director_auto_runs
                SET owner_token='', lease_expires_at=0
                WHERE run_id=?
                """,
                (run_id,),
            )
            conn.commit()


def _relevant_tasks(run: DirectorAutoRun, tasks: Iterable[TaskState]) -> list[TaskState]:
    if run.is_project_scope:
        # A project-scope run spans global prep (episode 0) and every episode it
        # is producing, so it watches all mainline task types.
        return [task for task in tasks if task.task_type in AUTO_TASK_TYPES]
    return [
        task
        for task in tasks
        if task.task_type in AUTO_TASK_TYPES
        and (task.episode in {0, run.episode})
    ]


def _task_label(task: TaskState) -> str:
    result = task.result if isinstance(task.result, dict) else {}
    scope_parts = [part.strip() for part in str(task.scope or "").split(":") if part.strip()]
    if task.task_type == "character_portrait":
        character = str(result.get("character_name") or "").strip()
        if not character and len(scope_parts) > 1:
            character = scope_parts[1]
        return f"{character}肖像" if character else "角色肖像"
    if task.task_type == "identity_image":
        character = str(result.get("character_name") or "").strip()
        identity = str(result.get("identity_name") or "").strip()
        if not character and len(scope_parts) > 1:
            character = scope_parts[1]
        if not identity and len(scope_parts) > 3:
            identity = scope_parts[3]
        if character and identity:
            return f"{character}「{identity}」身份图"
        return f"{character or identity or '角色'}身份图"
    if task.task_type == "single_video" and task.beat_num:
        return f"第 {task.episode} 集 Beat {task.beat_num} 视频"
    if task.task_type == "seedance2_prompt" and task.beat_num:
        return f"第 {task.episode} 集 Beat {task.beat_num} 提示词"
    labels = {
        "ingest_fast": "项目摄入",
        "screenplay_preprocess": "剧本预处理",
        "script_process": "剧本处理",
        "build_characters": "角色构建",
        "build_props": "道具构建",
        "build_episodes": "剧集规划",
        "identity_planner": "身份规划",
        "character_portrait": "角色肖像",
        "identity_image": "身份图生成",
        "script_writer": "剧本生成",
        "content_rewriter": "解说改写",
        "literal_script_writer": "解说稿生成",
        "director_notes": "导演说明",
        "build_scenes": "场景规划",
        "episode_scene_planner": "本集场景规划",
        "episode_prop_planner": "本集道具规划",
        "scene_reference_asset": "场景参考图",
        "scene_pano_generation": "场景 360 全景图",
        "prop_reference_asset": "道具参考图",
        "sketch_grid_generation": "草图网格",
        "sketch_generation": "草图生成",
        "sketch_regen": "草图重生成",
        "grid_regenerate": "草图网格重生成",
        "mainline_sketch_from_context": "草图生成",
        "mainline_frame_from_context": "首帧生成",
        "ai_identity_detection": "身份检测",
        "global_optimize_video": "全局优化",
        "selected_regen": "首帧生成",
        "render_plan": "渲染规划",
        "system_voice_setup": "系统声线准备",
        "audio_generation_indextts2": "音频生成",
        "indextts2_audio_generation": "音频生成",
        "audio_generation": "音频生成",
        "single_video": "视频生成",
        "seedance2_prompt": "2.0 提示词",
        "compose_episode": "成片合成",
    }
    return labels.get(task.task_type, task.task_type)


def _task_instruction(task: TaskState) -> str:
    """The step's own command, bracketed for the chat timeline.

    Automatic production narrates itself into the 捏导 conversation, and the
    user reads those lines as step instructions rather than as prose.  Wrapping
    the stage name in ``[]`` — ``[剧本处理] 已完成。`` — keeps every one of them
    visually identical, so the bracketed text is always "this is what the run is
    executing" and never part of a sentence about something else.
    """

    return f"[{_task_label(task)}]"


def _missing_character_portrait(task: TaskState) -> str | None:
    """Return the exact missing character for the one safe auto-repair case."""

    if task.task_type != "identity_image" or task.status != "failed":
        return None
    match = _MISSING_CHARACTER_PORTRAIT_RE.search(str(task.error or ""))
    if match is None:
        return None
    character = match.group("character").strip()
    return character or None


class DirectorAutoCoordinator:
    def __init__(self, store: DirectorAutoStore | None = None) -> None:
        self.store = store or DirectorAutoStore()
        self.owner_token = uuid.uuid4().hex
        self._workers: dict[str, asyncio.Task[None]] = {}
        self._stopping = False
        #: Application event loop captured at startup.  Task runners execute in
        #: lane pool threads that own a throw-away ``asyncio.run`` loop, so
        #: ``resume_paused_from_thread`` has to fan work back out to this loop.
        self._app_loop: asyncio.AbstractEventLoop | None = None
        #: 巡检任务：把「没人持租约却还是 running」的 run 重新拉起来。
        self._supervisor: asyncio.Task[None] | None = None
        #: Last continuation breadcrumb per run: ``(saw_write, last_tool_note)``.
        #: Used to tell "the agent only did reads" apart from "the agent wrote
        #: but produced no task" when the durable run has to pause.
        self._continue_notes: dict[str, tuple[bool, str]] = {}

    def _remember_continuation(self, run_id: str, *, wrote: bool, note: str) -> None:
        self._continue_notes[run_id] = (bool(wrote), str(note or ""))

    def _last_continuation(self, run_id: str) -> tuple[bool, str]:
        info = self._continue_notes.pop(run_id, None)
        if info is None:
            # No agent turn was recorded (e.g. the deterministic fast path
            # dispatched a stage): do not blame the agent for the pause.
            return True, ""
        return info

    async def start(
        self,
        *,
        username: str,
        ctx: ProjectContext,
        episode: int,
        voice_policy: str = "",
        scope: str = "episode",
        target_episodes: int = 0,
        config: dict[str, Any] | None = None,
        driver: str = "agent",
    ) -> DirectorAutoRun:
        tasks = await asyncio.to_thread(get_task_manager().list_tasks_for_project, ctx)
        now = _utc_now()
        run = DirectorAutoRun(
            run_id=uuid.uuid4().hex,
            username=username,
            project_id=ctx.project_id,
            episode=max(int(episode), 0),
            status="running",
            activated_at=now,
            updated_at=now,
            context_json=_serialize_context(ctx),
            # Adopt tasks already running when the user confirms auto mode;
            # only terminal history is baseline noise.
            baseline_task_ids=tuple(
                task.task_id for task in tasks if task.status in TERMINAL_STATUSES
            ),
            handled_task_ids=(),
            voice_policy=voice_policy if voice_policy in {"system", "custom"} else "",
            scope="project" if scope == "project" else "episode",
            target_episodes=max(int(target_episodes or 0), 0),
            config_json=json.dumps(config or {}, ensure_ascii=False),
            driver="deterministic" if driver == "deterministic" else "agent",
        )
        await asyncio.to_thread(self.store.upsert, run)
        # 巡检（reaper + 崩溃兜底）必须跟 run 一起起来。以前只有 ``resume`` 会拉起它，
        # 一旦启动路径失败，整条 run 再没人为它兜底。
        self._ensure_supervisor()
        self._ensure_worker(run)
        await self._broadcast_status(run)
        return run

    async def pause(
        self,
        *,
        username: str,
        project_id: str,
        reason: str = "",
        terminal_task_id: str | None = None,
        kind: str = "",
    ) -> DirectorAutoRun | None:
        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None:
            return None
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "status": "paused",
                "updated_at": _utc_now(),
                "last_error": reason,
                "pause_kind": kind or _pause_kind_for_reason(reason),
            }
        )
        await asyncio.to_thread(self.store.upsert, updated)
        await asyncio.to_thread(self.store.force_release_lease, run.run_id)
        await self._broadcast_status(updated, terminal_task_id=terminal_task_id)
        worker = self._workers.pop(run.run_id, None)
        if worker is not None and worker is not asyncio.current_task():
            worker.cancel()
        return updated

    async def suspend_for_confirmation(
        self,
        *,
        username: str,
        project_id: str,
        reason: str = "等待用户确认是否修改",
    ) -> DirectorAutoRun | None:
        """Suspend future auto steps without cancelling any queued/running task."""

        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None:
            return None
        if run.status == "awaiting_confirmation":
            return run
        if run.status != "running":
            raise ValueError("本集自动当前未在运行，不能进入修改确认状态")
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "status": "awaiting_confirmation",
                "updated_at": _utc_now(),
                "last_error": reason,
                "pause_kind": PAUSE_KIND_CONFIRM,
            }
        )
        await asyncio.to_thread(self.store.upsert, updated)
        await asyncio.to_thread(self.store.force_release_lease, run.run_id)
        await self._broadcast_status(updated)
        worker = self._workers.pop(run.run_id, None)
        if worker is not None and worker is not asyncio.current_task():
            worker.cancel()
        return updated

    async def resume_suspended(
        self,
        *,
        username: str,
        project_id: str,
    ) -> DirectorAutoRun | None:
        """Resume the same durable run after the user declines a proposed change."""

        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None:
            return None
        if run.status == "running":
            self._ensure_worker(run)
            return run
        if run.status != "awaiting_confirmation":
            raise ValueError("只有等待修改确认的本集自动任务可以恢复")
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "status": "running",
                "updated_at": _utc_now(),
                "last_error": "",
                "pause_kind": "",
                "recovery_attempts": 0,
                # A user decision is a fresh start: do not hold the attempts
                # spent before the pause against the next failure.
                "stage_key": "",
                "stage_attempts": 0,
                "next_attempt_at": 0.0,
            }
        )
        await asyncio.to_thread(self.store.upsert, updated)
        self._ensure_worker(updated)
        await self._broadcast_status(updated)
        return updated

    @staticmethod
    def _cost_gate_blocks_resume(run: DirectorAutoRun) -> bool:
        """停在收费闸门、且这一集还没确认时，任何「继续」都要被拦下。

        只读项目配置（不跑预估），所以不会因为预估失败而卡住恢复路径。运维把
        ``production_estimate_gate`` 关掉即放行——与 :meth:`_pause_gate` 同一口径。
        """

        if COST_ESTIMATE_GATE_TAG not in str(run.last_error or ""):
            return False
        from novelvideo.project_config import (
            cost_estimate_confirmed,
            cost_estimate_gate_enabled,
        )

        project_name = run.context.project_name
        if not cost_estimate_gate_enabled(run.username, project_name):
            return False
        episode = int(run.episode or 0)
        if episode <= 0:
            # 认不出集号就 fail-closed：这条 run 本来就停在闸门上，放行只会白花钱。
            return True
        return not cost_estimate_confirmed(run.username, project_name, episode)

    async def resume_paused(
        self,
        *,
        username: str,
        project_id: str,
        voice_policy: str | None = None,
        auto: bool = False,
    ) -> DirectorAutoRun | None:
        """Continue a hard-paused run (unmet prerequisite or retryable failure).

        ``resume_suspended`` answers a *declined change* and therefore only
        accepts ``awaiting_confirmation``.  This is the explicit "继续" path for
        a run the coordinator itself parked with ``pause()`` — the voice-setup
        gate being the common case.  Terminal statuses stay terminal; the user
        restarts those with a fresh auto run so a finished/failed run is never
        silently replayed.

        唯一的例外是**收费**的 ``cost_estimate`` 闸门：它只能由客户在报价卡上确认
        （确认端点先预扣伴点、再写答案、最后才调到这里），所以未确认时这里一律拒绝，
        否则「继续」会绕过预扣直接开跑花钱的阶段。
        """

        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None:
            return None
        if run.status == "running":
            self._ensure_worker(run)
            return run
        if run.status != "paused":
            raise ValueError("只有已暂停的本集自动任务可以继续")
        if self._cost_gate_blocks_resume(run):
            raise ValueError(COST_ESTIMATE_RESUME_BLOCKED_ERROR)
        # 自动兜底续跑自带预算：撞满上限就让巡检把它标成 needs_human，人工来定。
        # 人工点击（auto=False）永远放行，并把预算清零（人已经介入）。
        recovery_attempts = int(run.recovery_attempts or 0)
        if auto and recovery_attempts >= MAX_RECOVERY_ATTEMPTS:
            raise ValueError(AUTO_RECOVERY_EXHAUSTED_ERROR)
        normalized_policy = (
            voice_policy if voice_policy in {"system", "custom"} else run.voice_policy
        )
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "status": "running",
                "updated_at": _utc_now(),
                "last_error": "",
                "pause_kind": "",
                "recovery_attempts": recovery_attempts + 1 if auto else 0,
                "voice_policy": normalized_policy,
                # A user decision is a fresh start: do not hold the attempts
                # spent before the pause against the next failure. The
                # dispatcher's stage signatures go with them, otherwise the
                # deterministic fast path still sees the paused stage as already
                # attempted and refuses to re-enqueue it, silently degrading
                # every "继续" into the slow agent fallback.
                #
                # ``stage_key`` is deliberately kept: it is the marker the loop
                # uses to tell "advanced to another stage" (progress, so the
                # recovery budget resets) from "the same stage failed again"
                # (no progress). Clearing it here would make every resume look
                # like progress and defeat MAX_RECOVERY_ATTEMPTS.
                "recovery_keys": self._clear_stage_signatures(run),
                "stage_attempts": 0,
                "next_attempt_at": 0.0,
            }
        )
        await asyncio.to_thread(self.store.upsert, updated)
        self._ensure_worker(updated)
        await self._broadcast_status(updated)
        return updated

    def resume_paused_from_thread(
        self,
        *,
        username: str,
        project_id: str,
        voice_policy: str | None = None,
    ) -> bool:
        """Best-effort ``resume_paused`` from a task-runner worker thread.

        Returns False when the application loop is unknown/closed or the call
        could not be handed off, so callers can fall back to the manual
        "继续" path.  Never raises: this runs on the tail of a task and must not
        turn a successful task into a failure.
        """

        loop = self._app_loop
        if loop is None or loop.is_closed():
            logger.info(
                "director auto resume skipped (no app loop): project_id=%s",
                project_id,
            )
            return False
        try:
            handle = asyncio.run_coroutine_threadsafe(
                self.resume_paused(
                    username=username,
                    project_id=project_id,
                    voice_policy=voice_policy,
                ),
                loop,
            )
        except Exception:  # noqa: BLE001 - continuation is strictly best-effort
            logger.exception(
                "director auto resume hand-off failed: project_id=%s", project_id
            )
            return False
        handle.add_done_callback(
            lambda done, pid=project_id: self._log_detached_resume(done, pid)
        )
        return True

    def resume_after_system_voice_setup_from_thread(
        self,
        *,
        username: str,
        project_id: str,
    ) -> bool:
        """Continue the run the *voice gate* paused, now that voices exist.

        Only a run parked with :data:`VOICE_POLICY_REQUIRED_ERROR` is picked up,
        so a pause caused by something else keeps its own reason and its own
        decision.  The run adopts ``voice_policy="system"`` because preparing
        system voices is itself the user's choice of that policy.
        """

        loop = self._app_loop
        if loop is None or loop.is_closed():
            logger.info(
                "director auto voice continuation skipped (no app loop): project_id=%s",
                project_id,
            )
            return False
        try:
            handle = asyncio.run_coroutine_threadsafe(
                self._continue_paused_after_voice_setup(
                    username=username,
                    project_id=project_id,
                ),
                loop,
            )
        except Exception:  # noqa: BLE001 - continuation is strictly best-effort
            logger.exception(
                "director auto voice continuation hand-off failed: project_id=%s",
                project_id,
            )
            return False
        handle.add_done_callback(
            lambda done, pid=project_id: self._log_detached_resume(done, pid)
        )
        return True

    async def _continue_paused_after_voice_setup(
        self,
        *,
        username: str,
        project_id: str,
    ) -> DirectorAutoRun | None:
        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None or run.status != "paused":
            return run
        if str(run.last_error or "").strip() != VOICE_POLICY_REQUIRED_ERROR:
            return run
        return await self.resume_paused(
            username=username,
            project_id=project_id,
            voice_policy=run.voice_policy or "system",
        )

    @staticmethod
    def _log_detached_resume(done: Any, project_id: str) -> None:
        try:
            error = done.exception()
        except Exception:  # noqa: BLE001 - cancelled/failed hand-off
            return
        if isinstance(error, ValueError):
            # Run is no longer paused (already continued elsewhere): benign.
            return
        if error is not None:
            logger.warning(
                "director auto detached resume failed: project_id=%s error=%s",
                project_id,
                error,
            )

    async def get(self, *, username: str, project_id: str) -> DirectorAutoRun | None:
        return await asyncio.to_thread(self.store.get, username, project_id)

    async def get_by_project(self, project_id: str) -> DirectorAutoRun | None:
        """项目自己的 run（不论归属者）——闸门回答与恢复都以它为准。"""

        return await asyncio.to_thread(self.store.get_by_project, project_id)

    async def resume(self) -> None:
        self._stopping = False
        try:
            self._app_loop = asyncio.get_running_loop()
        except RuntimeError:  # pragma: no cover - always started from the loop
            self._app_loop = None
        for run in await asyncio.to_thread(self.store.active):
            self._ensure_worker(run)
        self._ensure_supervisor()

    async def shutdown(self) -> None:
        self._stopping = True
        supervisor = self._supervisor
        self._supervisor = None
        workers = list(self._workers.values())
        self._workers.clear()
        for worker in workers:
            worker.cancel()
        if supervisor is not None:
            supervisor.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        if supervisor is not None:
            await asyncio.gather(supervisor, return_exceptions=True)

    def _ensure_worker(self, run: DirectorAutoRun) -> None:
        existing = self._workers.get(run.run_id)
        if existing is not None and not existing.done():
            return
        worker = asyncio.create_task(
            self._run_with_lease(run.run_id, run.username, run.project_id),
            name=f"director-auto:{run.project_id}:{run.episode}",
        )
        self._workers[run.run_id] = worker
        worker.add_done_callback(lambda _done, run_id=run.run_id: self._workers.pop(run_id, None))

    def _ensure_supervisor(self) -> None:
        """保证整个 app 生命周期里有一个巡检任务在跑。"""

        existing = self._supervisor
        if existing is not None and not existing.done():
            return
        self._supervisor = asyncio.create_task(
            self._supervise_loop(), name="director-auto-supervisor"
        )

    async def _supervise_loop(self) -> None:
        while not self._stopping:
            try:
                await self._reap_stalled_runs()
            except Exception:  # noqa: BLE001 - 巡检自己绝不能死
                logger.exception("director auto supervision pass failed")
            try:
                await self._reap_unprogressing_runs()
            except Exception:  # noqa: BLE001 - 巡检自己绝不能死
                logger.exception("director auto progress pass failed")
            try:
                await self._auto_answer_stale_identity_gates()
            except Exception:  # noqa: BLE001 - 巡检自己绝不能死
                logger.exception("director auto identity gate pass failed")
            try:
                await self._auto_resume_stale_hard_pauses()
            except Exception:  # noqa: BLE001 - 巡检自己绝不能死
                logger.exception("director auto recovery pass failed")
            await asyncio.sleep(REAPER_SECONDS)

    async def _auto_resume_stale_hard_pauses(self) -> None:
        """服务端兜底续跑：浏览器关掉后，可重试的硬暂停也不能永久停。

        工作台的自动续跑活在浏览器里；客户一关标签页，任何 ``paused`` 就再没人
        唤醒。这里只挑 :data:`PAUSE_KIND_RETRYABLE`（``stage`` 级重试已用尽的
        失败），在宽限期后替它续跑一次，并且**带持久化预算**：只有 run 真正换到
        下一个 stage（``recovery_attempts`` 在那边清零）或人工介入，预算才回满。
        闸门 / 阻塞型 / 配置缺失 / 致命失败各有自己的入口，绝不在这里放行。
        """

        cutoff = (
            datetime.now(timezone.utc) - timedelta(seconds=HARD_PAUSE_GRACE_SECONDS)
        ).isoformat()
        stale = await asyncio.to_thread(
            self.store.paused_kind_before, PAUSE_KIND_RETRYABLE, cutoff
        )
        for run in stale:
            if int(run.recovery_attempts or 0) >= MAX_RECOVERY_ATTEMPTS:
                await self._mark_needs_human(run)
                continue
            try:
                await self.resume_paused(
                    username=run.username,
                    project_id=run.project_id,
                    auto=True,
                )
            except ValueError:
                # 预算刚好用尽 / 已被别的路径处理：交给 needs_human 兜底。
                await self._mark_needs_human(run)
                continue
            except Exception:  # noqa: BLE001 - 兜底失败不能拖垮巡检
                logger.exception(
                    "director auto hard-pause auto-resume failed: project_id=%s",
                    run.project_id,
                )
                continue
            logger.info(
                "director auto auto-resumed stale hard pause project_id=%s run_id=%s",
                run.project_id,
                run.run_id,
            )

    async def _mark_needs_human(self, run: DirectorAutoRun) -> None:
        """自动恢复已用尽：把 run 标成 ``needs_human``，停下等人工判断。"""

        if str(run.pause_kind or "") == PAUSE_KIND_NEEDS_HUMAN:
            return
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "updated_at": _utc_now(),
                "pause_kind": PAUSE_KIND_NEEDS_HUMAN,
            }
        )
        await asyncio.to_thread(self.store.upsert, updated)
        await self._broadcast_status(updated)

    async def _reap_unprogressing_runs(self) -> None:
        """``status=running`` 但「真的没有进展」太久 → 重拉 worker（有界）。

        与 :meth:`_reap_stalled_runs` 的差别：后者只管「租约掉了」（worker 死了），
        这里管「租约还在、心跳还在续，但事件循环/agent turn 卡住，没有任何 stage
        推进」。判据是 ``updated_at`` 太久没动 **且** 项目当前没有相关任务在飞
        （长渲染可以几十分钟没有 stage 变化，那不算卡死）。
        """

        cutoff = (
            datetime.now(timezone.utc) - timedelta(seconds=STALL_PROGRESS_SECONDS)
        ).isoformat()
        stale = await asyncio.to_thread(self.store.running_all, cutoff)
        for run in stale:
            worker = self._workers.get(run.run_id)
            if worker is None or worker.done():
                # 没有本地活着的 worker：要么 run 归别的进程（绝不能抢它的租约），
                # 要么根本没有 worker —— 后者交给 _reap_stalled_runs 处理。
                continue
            if await self._has_active_task(run):
                continue
            if int(run.recovery_attempts or 0) >= MAX_RECOVERY_ATTEMPTS:
                await self.pause(
                    username=run.username,
                    project_id=run.project_id,
                    reason="制作长时间没有进展，自动重拉已用尽，请人工检查后继续",
                    kind=PAUSE_KIND_NEEDS_HUMAN,
                )
                continue
            logger.warning(
                "director auto re-arming unprogressing run project_id=%s run_id=%s stage=%s",
                run.project_id,
                run.run_id,
                run.stage_key,
            )
            bumped = DirectorAutoRun(
                **{
                    **asdict(run),
                    "updated_at": _utc_now(),
                    "recovery_attempts": int(run.recovery_attempts or 0) + 1,
                }
            )
            await asyncio.to_thread(self.store.upsert, bumped)
            worker.cancel()
            await asyncio.to_thread(self.store.force_release_lease, run.run_id)
            self._workers.pop(run.run_id, None)
            self._ensure_worker(bumped)

    async def _has_active_task(self, run: DirectorAutoRun) -> bool:
        """项目当前是否有相关任务在跑（有就不算卡死：那是正常的在飞工作）。"""

        try:
            tasks = await asyncio.to_thread(
                get_task_manager().list_tasks_for_project, run.context
            )
        except Exception:  # noqa: BLE001 - 读不到就当没有，交由 reaper 兜底
            return False
        return any(
            task.status in ACTIVE_STATUSES for task in _relevant_tasks(run, tasks)
        )

    async def _auto_answer_stale_identity_gates(self) -> None:
        """身份图闸门的服务端兜底：没人看着的时候也不会永久卡住。

        这一档的语义就是「不指定就由 AI 生成」，没有必须人做主的决定；工作台开着
        时前端会给一段宽限期再自动确认，这里负责「浏览器不在」的情况。真正需要
        客户点头的 ``character_images``（首次角色肖像）与 ``cost_estimate``（付费
        报价）不在这里放行。
        """

        from novelvideo.project_config import confirm_identity_images

        cutoff = (
            datetime.now(timezone.utc) - timedelta(seconds=IDENTITY_GATE_GRACE_SECONDS)
        ).isoformat()
        stale = await asyncio.to_thread(self.store.paused_identity_gate_before, cutoff)
        for run in stale:
            episode = int(run.episode or 0)
            if episode <= 0:
                # 认不出集号就 fail-closed：闸门本来就没有可写的答案。
                continue
            try:
                await asyncio.to_thread(
                    confirm_identity_images,
                    run.username,
                    run.context.project_name,
                    episode,
                )
                await self.resume_paused(
                    username=run.username, project_id=run.project_id
                )
            except ValueError:
                # 已被前端或别的路径确认并恢复：好事，不该记成错误。
                continue
            except Exception:  # noqa: BLE001 - 兜底失败不能拖垮巡检
                logger.exception(
                    "director auto identity gate auto-confirm failed: project_id=%s",
                    run.project_id,
                )
                continue
            logger.info(
                "director auto auto-confirmed stale identity gate "
                "project_id=%s run_id=%s episode=%s",
                run.project_id,
                run.run_id,
                episode,
            )

    async def _reap_stalled_runs(self) -> None:
        """把「worker 悄悄没了」的 run 重新拉起来。

        worker 可能在完全不碰 durable 行的前提下死掉：续租连续失败会让心跳
        ``parent.cancel()`` 掉它，行还留在 ``running``；而任务行仍在流动，
        所以直到这一批在飞任务排空才会看出「这一集停了」。除了这里没有任何
        地方会把它重新 arm，所以必须巡检。
        """

        now = datetime.now(timezone.utc).timestamp()
        for run in await asyncio.to_thread(self.store.running_without_lease, now):
            worker = self._workers.get(run.run_id)
            if worker is not None and not worker.done():
                continue
            logger.warning(
                "director auto re-arming stalled run project_id=%s run_id=%s stage=%s",
                run.project_id,
                run.run_id,
                run.stage_key,
            )
            self._ensure_worker(run)

    async def _run_with_lease(self, run_id: str, username: str, project_id: str) -> None:
        for _ in range(MAX_LEASE_CLAIM_ATTEMPTS):
            if self._stopping:
                return
            claimed = await asyncio.to_thread(
                self.store.claim_lease,
                run_id,
                self.owner_token,
            )
            if claimed:
                break
            run = await asyncio.to_thread(self.store.get, username, project_id)
            if run is None or run.run_id != run_id or run.status != "running":
                return
            await asyncio.sleep(HEARTBEAT_SECONDS)
        else:
            logger.warning(
                "director auto gave up claiming lease run_id=%s after %s attempts",
                run_id,
                MAX_LEASE_CLAIM_ATTEMPTS,
            )
            return
        parent = asyncio.current_task()
        heartbeat = asyncio.create_task(
            self._lease_heartbeat(run_id, parent),
            name=f"director-auto-heartbeat:{project_id}",
        )
        try:
            await self._run(run_id, username, project_id)
        except asyncio.CancelledError:
            logger.warning(
                "director auto worker cancelled run_id=%s (run row untouched)", run_id
            )
            raise
        except Exception:  # noqa: BLE001 - 死掉的 worker 不能没有日志
            logger.exception("director auto worker crashed run_id=%s", run_id)
        finally:
            heartbeat.cancel()
            await asyncio.gather(heartbeat, return_exceptions=True)
            await asyncio.to_thread(
                self.store.release_lease,
                run_id,
                self.owner_token,
            )

    async def _lease_heartbeat(
        self,
        run_id: str,
        parent: asyncio.Task[None] | None,
    ) -> None:
        """续租；瞬时失败重试若干次，只有连续失败才判定租约丢失。

        续租走共享线程池（``asyncio.to_thread``），重批量任务会把线程池和事件
        循环堵住几十秒，此时单次失败是正常的。旧实现「一次失败就 cancel」会让
        worker 无声死掉、run 卡在 ``running``，所以这里必须容忍 + 留痕。
        """

        misses = 0
        while not self._stopping:
            await asyncio.sleep(HEARTBEAT_SECONDS)
            try:
                renewed = await asyncio.to_thread(
                    self.store.renew_lease,
                    run_id,
                    self.owner_token,
                )
            except Exception:  # noqa: BLE001 - sqlite 写锁/超时都算瞬时
                logger.warning(
                    "director auto lease renew raised run_id=%s attempt=%s",
                    run_id,
                    misses + 1,
                    exc_info=True,
                )
                renewed = False
            if renewed:
                misses = 0
                continue
            misses += 1
            logger.warning(
                "director auto lease renew failed run_id=%s attempt=%s/%s",
                run_id,
                misses,
                LEASE_RENEW_ATTEMPTS,
            )
            if misses < LEASE_RENEW_ATTEMPTS:
                continue
            logger.error("director auto lease lost, stopping worker run_id=%s", run_id)
            if parent is not None and not parent.done():
                parent.cancel()
            return

    async def _owns_run(self, run_id: str) -> bool:
        return await asyncio.to_thread(
            self.store.owns_lease,
            run_id,
            self.owner_token,
        )

    async def _update_owned(self, run: DirectorAutoRun) -> bool:
        return await asyncio.to_thread(
            self.store.update_if_owned,
            run,
            self.owner_token,
        )

    async def _pause_owned(
        self,
        *,
        run_id: str,
        username: str,
        project_id: str,
        reason: str = "",
        terminal_task_id: str | None = None,
        kind: str = "",
    ) -> DirectorAutoRun | None:
        """Pause from a worker only if this coordinator still owns the run."""

        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None or run.run_id != run_id:
            return None
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "status": "paused",
                "updated_at": _utc_now(),
                "last_error": reason,
                "pause_kind": kind or _pause_kind_for_reason(reason),
            }
        )
        if not await self._update_owned(updated):
            return None
        await asyncio.to_thread(
            self.store.release_lease,
            run.run_id,
            self.owner_token,
        )
        await self._broadcast_status(updated, terminal_task_id=terminal_task_id)
        worker = self._workers.pop(run.run_id, None)
        if worker is not None and worker is not asyncio.current_task():
            worker.cancel()
        return updated

    async def _suspend_owned(
        self,
        *,
        run_id: str,
        username: str,
        project_id: str,
        reason: str = "",
        terminal_task_id: str | None = None,
        kind: str = "",
    ) -> DirectorAutoRun | None:
        """Pause a stalled run for a user decision, keeping it resumable.

        Unlike :meth:`_pause_owned`, the run enters ``awaiting_confirmation`` so
        the frontend can offer the user a choice (keep waiting / stop) instead of
        silently abandoning automatic production.
        """

        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None or run.run_id != run_id:
            return None
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "status": "awaiting_confirmation",
                "updated_at": _utc_now(),
                "last_error": reason,
                "pause_kind": kind or PAUSE_KIND_CONFIRM,
            }
        )
        if not await self._update_owned(updated):
            return None
        await asyncio.to_thread(
            self.store.release_lease,
            run.run_id,
            self.owner_token,
        )
        await self._broadcast_status(updated, terminal_task_id=terminal_task_id)
        worker = self._workers.pop(run.run_id, None)
        if worker is not None and worker is not asyncio.current_task():
            worker.cancel()
        return updated

    async def _block_shot_and_continue(
        self,
        *,
        run: DirectorAutoRun,
        episode: int,
        beat_num: int,
        stage: str,
        code: str,
        reason: str,
        kind: str = "video",
    ) -> DirectorAutoRun | None:
        """Give up on one shot **without stalling the whole run**.

        工作台不允许假死：单个镜头过不了上游审核（或重试耗尽）时，不再把整条 run
        停成 ``paused`` 等人工介入，而是：

        * 先做一次**本地降级**，让该镜仍有可用产物、下游不受影响：
          - ``kind="video"``：用该镜已生成的首帧合成一支同规格短片
            （``render_still_clip``，不触网、不占额度）；
          - ``kind="frame"``：把该镜已有的草图当作首帧落盘（首帧审核过不了时的兜底）。
        * 把该镜写进 ``blocked_shots``，客户端据此醒目报错、逐镜标记；
        * 把该镜的 dispatch 签名标记为「已尝试」，确定性派发会跳过它去下一镜。

        返回值是更新后的 run（仍为 ``running``），调用方只需继续循环即可；返回
        ``None`` 表示租约已不属于本 worker，调用方应直接退出。
        """

        ctx = run.context
        ep_str = f"ep{episode:03d}"
        frame = ctx.output_dir / "frames" / ep_str / f"beat_{beat_num:02d}.png"
        video = ctx.output_dir / "videos" / "beats" / ep_str / f"beat_{beat_num:02d}.mp4"
        sketch = ctx.output_dir / "sketches" / ep_str / f"beat_{beat_num:02d}.png"

        degraded = False
        if kind == "video":
            from novelvideo.generators.fallback_clip import render_still_clip

            degraded = await asyncio.to_thread(render_still_clip, frame, video)
        elif kind == "frame":
            degraded = await asyncio.to_thread(self._degrade_first_frame, frame, sketch)

        entry = {
            "episode": int(episode),
            "beat": int(beat_num),
            "stage": str(stage or "single_video"),
            "code": str(code or "unrenderable"),
            "reason": reason,
            "degraded": bool(degraded),
            "at": _utc_now(),
        }
        # 同一镜重复阻塞时只保留最新一条，避免刷屏。
        kept = [
            item
            for item in run.blocked_shots
            if (
                int(item.get("episode", 0) or 0),
                int(item.get("beat", 0) or 0),
            )
            != (int(episode), int(beat_num))
        ]
        blocked = tuple([*kept, entry])

        stage_key = str(entry["stage"])
        # 让确定性派发跳过这一镜（签名与 ``_dispatch_single_videos`` 一致）。
        skip_signature = f"dispatch:{stage_key}:{episode}:{beat_num}"
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "updated_at": _utc_now(),
                "status": "running",
                "blocked_shots": blocked,
                "recovery_keys": tuple(
                    sorted({*run.recovery_keys, skip_signature})
                ),
                "stage_key": stage_key,
                "stage_attempts": 0,
                "next_attempt_at": datetime.now(timezone.utc).timestamp(),
                "last_error": reason,
            }
        )
        if not await self._update_owned(updated):
            return None
        return updated

    @staticmethod
    def _degrade_first_frame(frame: Path, sketch: Path) -> bool:
        """首帧生成不过审时的本地兜底：用已有草图顶替首帧落盘。"""

        if frame.is_file():
            return False
        if not sketch.is_file():
            return False
        try:
            frame.parent.mkdir(parents=True, exist_ok=True)
            frame.write_bytes(sketch.read_bytes())
        except OSError:
            return False
        return True

    async def clear_blocked_shot(
        self,
        *,
        username: str,
        project_id: str,
        episode: int,
        beat_num: int,
    ) -> DirectorAutoRun | None:
        """用户重做某个被降级/跳过的镜头后，清掉它在 run 上的阻塞标记。

        只清标记，不删产物、不重新派发：重做本身由调用方（工作台的「重做该镜」）
        显式入队单镜生成，这里只是让错误条不再继续挂着一面已重做的红牌。
        """

        run = await asyncio.to_thread(self.store.get, username, project_id)
        if run is None:
            return None
        remaining = tuple(
            item
            for item in run.blocked_shots
            if (int(item.get("episode", 0) or 0), int(item.get("beat", 0) or 0))
            != (int(episode), int(beat_num))
        )
        if len(remaining) == len(run.blocked_shots):
            return run
        updated = DirectorAutoRun(
            **{
                **asdict(run),
                "updated_at": _utc_now(),
                "blocked_shots": remaining,
            }
        )
        await asyncio.to_thread(self.store.upsert, updated)
        await self._broadcast_status(updated)
        return updated

    def _clear_stage_signatures(self, run: DirectorAutoRun) -> tuple[str, ...]:
        """Drop the dispatcher's per-stage dedupe keys so a retry can re-enqueue.

        ``recovery_keys`` mixes two families: ``missing-character-portrait:*``
        repairs, which must survive, and ``dispatch:*`` stage signatures, which
        must not, or the deterministic fast path would refuse to re-enqueue the
        very stage being retried. Every dispatch signature is dropped rather than
        only the failing stage's prefix, because the task type a stage executes
        as does not always match its signature segment (sketches run as
        ``sketch_grid_generation`` but sign as ``sketch_generation``).
        """

        return tuple(key for key in run.recovery_keys if not key.startswith("dispatch:"))

    async def _grant_stage_retry(
        self,
        *,
        run: DirectorAutoRun,
        task: TaskState | None,
        reason: str,
    ) -> tuple[bool, int]:
        """Spend one bounded retry on the stage the durable run is driving.

        Returns ``(granted, attempt)``. When granted, the run is updated with the
        new budget, the stage dedupe signatures are cleared and a backoff gate is
        armed; the caller only has to notify and keep the loop going.
        """

        if not _stage_retry_enabled():
            return False, 0
        key = _stage_key_for(task, run)
        attempt = run.stage_attempts + 1 if run.stage_key == key else 1
        if attempt > MAX_STAGE_ATTEMPTS:
            return False, attempt
        now = datetime.now(timezone.utc).timestamp()
        granted = DirectorAutoRun(
            **{
                **asdict(run),
                "updated_at": _utc_now(),
                "recovery_keys": self._clear_stage_signatures(run),
                "stage_key": key,
                "stage_attempts": attempt,
                "next_attempt_at": now + _stage_retry_delay(attempt),
                "last_error": f"{RETRY_REASON_PREFIX}{attempt}/{MAX_STAGE_ATTEMPTS}] {reason}",
            }
        )
        if not await self._update_owned(granted):
            return False, attempt
        return True, attempt

    async def _broadcast_status(
        self,
        run: DirectorAutoRun,
        *,
        terminal_task_id: str | None = None,
    ) -> None:
        await broadcast_project_chat_event(
            username=run.username,
            project_id=run.project_id,
            payload={
                "type": "director.auto.status",
                "scope": {"kind": "project", "id": run.project_id, "surface": "director"},
                "status": run.status,
                "episode": run.episode,
                "run_id": run.run_id,
                "message": run.last_error or None,
                "terminal_task_id": terminal_task_id,
                "voice_policy": run.voice_policy or None,
                "pause_kind": run.pause_kind or None,
                "recovery_attempts": int(run.recovery_attempts or 0),
            },
        )

    async def _notify(self, run: DirectorAutoRun, text: str) -> dict[str, Any]:
        ctx = run.context
        message = await asyncio.to_thread(
            chat_service.add_assistant_message,
            run.username,
            run.project_id,
            text,
            [],
            project_dir=ctx.output_dir,
            project_state_dir=ctx.state_dir,
        )
        await broadcast_project_chat_event(
            username=run.username,
            project_id=run.project_id,
            payload={
                "type": "assistant.message",
                "scope": {"kind": "project", "id": run.project_id, "surface": "director"},
                "message": message,
            },
        )
        return message

    async def _agent_continue(
        self,
        run: DirectorAutoRun,
        *,
        final_delivery: bool = False,
        instruction: str | None = None,
    ) -> bool:
        stored_ctx = run.context
        try:
            ctx = await resolve_project_context(
                user={
                    "id": stored_ctx.requester_user_id,
                    "username": stored_ctx.requester_username,
                },
                project_id=run.project_id,
                required_role="editor",
            )
        except Exception as exc:  # noqa: BLE001
            await self._pause_owned(
                run_id=run.run_id,
                username=run.username,
                project_id=run.project_id,
                reason=f"项目权限校验失败：{exc}",
            )
            await self._notify(run, "本集自动已暂停：当前用户已无权继续修改该项目。")
            return False
        # A user-driven turn and a durable continuation share the same project
        # lock. Wait instead of treating ordinary chat activity as auto failure.
        for _ in range(120):
            if not chat_service.chat_run_lock_is_active(run.username, run.project_id):
                break
            latest = await asyncio.to_thread(self.store.get, run.username, run.project_id)
            if latest is None or latest.status != "running":
                return False
            await asyncio.sleep(0.5)
        else:
            await self._pause_owned(
                run_id=run.run_id,
                username=run.username,
                project_id=run.project_id,
                reason="等待捏导空闲超时",
            )
            await self._notify(run, "本集自动已暂停：捏导长时间处于忙碌状态。")
            return False
        if run.is_project_scope:
            base_prompt = (
                "所有剧集的成片合成均已完成。请只读取并展示最终成片，然后简短收口；不要启动新的写任务。"
                if final_delivery
                else (
                    "继续自动制作：若项目准备（配置/角色/分集/肖像）尚未完成，只推进首个缺失的全局步骤；"
                    "否则只推进第 {episode} 集的下一步。只启动一个写任务，完成后收口。"
                ).format(episode=run.episode)
            )
            run_mode_block = (
                "\n\n[DRAMACLAW_RUN_MODE]\nmode=pipeline_auto\n"
                "This is a durable, server-owned one-click production run already authorized by the "
                "user. Advance the mainline pipeline from wherever it is: complete global preparation "
                "(characters, episodes, portraits) and then each episode through final composition, "
                "starting at most one write task per turn. Missing output with satisfied prerequisites "
                "should be generated without per-step confirmation. Do not stop between episodes. "
                "Pause only for: a task failure or cancellation, a missing required configuration, a "
                "missing voice policy when voice prerequisites block audio, destructive actions, or a "
                "genuinely ambiguous choice. Do not ask the user to confirm each step.\n"
                "In the same turn: read whatever state you need at most once, then start the "
                "single write task before ending the turn. Never describe a tool instead of "
                "calling it, and never end a turn on a read-only check.\n"
                "[/DRAMACLAW_RUN_MODE]"
            )
        else:
            base_prompt = (
                "第 {episode} 集成片合成已完成。请只读取并展示正式成片，然后简短收口；不要启动新的写任务。"
                if final_delivery
                else (
                    "只继续第 {episode} 集的下一步。不得启动、修改或推进其他集；"
                    "如果第 {episode} 集已经完成最终合成，只展示并收口。"
                )
            ).format(episode=run.episode)
            run_mode_block = (
                "\n\n[DRAMACLAW_RUN_MODE]\nmode=episode_auto\n"
                "This is a durable server-owned continuation already confirmed by the user. "
                "Inspect current state and start at most one safe missing mainline task. Do not ask "
                "for per-step confirmation. Missing output with satisfied prerequisites should be generated. "
                "Pause for a current-step failure, destructive action, ambiguity, missing voice choice, or "
                "unmet prerequisite, except for one exact Portrait repair explicitly authorized in the "
                "instruction above. In the same turn: read whatever state you need at most once, then "
                "start the single write task before ending the turn. Never describe a tool instead of "
                "calling it, and never end a turn on a read-only check.\n[/DRAMACLAW_RUN_MODE]"
            )
        prompt = instruction or base_prompt
        prompt += run_mode_block
        if final_delivery:
            pack_delivery = _film_pack_delivery_block()
            if pack_delivery:
                prompt += f"\n\n{pack_delivery}"
        if run.is_project_scope and run.target_episodes > 0:
            prompt += f"\n\n分集规划目标集数：{run.target_episodes}。"
        if run.voice_policy == "system":
            prompt += (
                "\n\n[DRAMACLAW_VOICE_POLICY]\npolicy=system\n"
                "The user explicitly authorized system voices when starting this episode auto run. "
                "If the current next_step is voice_setup and voices are missing, call "
                "dramaclaw_prepare_system_voices(confirmed=true) without asking again. This only "
                "prepares voices; audio generation remains a later turn.\n[/DRAMACLAW_VOICE_POLICY]"
            )
        elif run.voice_policy == "custom":
            prompt += (
                "\n\n[DRAMACLAW_VOICE_POLICY]\npolicy=custom\n"
                "The user chose uploaded/recorded custom voices. Never substitute system voices. "
                "If required custom voices are still missing at voice_setup, call "
                "dramaclaw_control_episode_auto(action='pause'), then explain the missing items and "
                "ask the user to upload or record them in 捏塘. Do not start audio generation. "
                "Once the user reports the voices are ready, call "
                "dramaclaw_control_episode_auto(action='continue', voice_policy='custom') — the run "
                "is 'paused', so action='resume' would be rejected."
                "\n[/DRAMACLAW_VOICE_POLICY]"
            )
        turn_id = f"director-auto-{run.run_id}-{uuid.uuid4().hex[:10]}"
        saw_write = False
        last_tool_note = ""

        async def on_event(event: dict[str, Any]) -> None:
            nonlocal saw_write, last_tool_note
            if event.get("type") in {"tool_started", "tool_updated", "tool_update"}:
                name = _event_tool_name(event)
                if name:
                    detail = _event_failure_detail(event)
                    last_tool_note = f"{name}（{detail}）" if detail else name
                if _event_is_write_tool(event):
                    saw_write = True
            if event.get("type") == "assistant_message" and isinstance(event.get("message"), dict):
                await broadcast_project_chat_event(
                    username=run.username,
                    project_id=run.project_id,
                    payload={
                        "type": "assistant.message",
                        "scope": {"kind": "project", "id": run.project_id, "surface": "director"},
                        "turn_id": turn_id,
                        "message": event["message"],
                    },
                )

        try:
            await asyncio.wait_for(
                chat_service.stream_assistant_reply(
                    run.username,
                    run.project_id,
                    prompt,
                    on_event,
                    project_dir=ctx.output_dir,
                    project_state_dir=ctx.state_dir,
                    surface="director",
                    turn_id=turn_id,
                    route_prompt="自动继续下一步",
                ),
                timeout=AGENT_CONTINUE_TIMEOUT_SECONDS,
            )
            self._remember_continuation(
                run.run_id, wrote=saw_write, note=last_tool_note
            )
            return saw_write
        except TimeoutError:
            logger.warning(
                "director auto continuation timed out project=%s", run.project_id
            )
            await self._pause_owned(
                run_id=run.run_id,
                username=run.username,
                project_id=run.project_id,
                reason="捏导续跑超时，未在限定时间内返回",
            )
            await self._notify(
                run, "本集自动已暂停：捏导续跑超时，稍后会自动重试或需要人工检查。"
            )
            return False
        except Exception as exc:  # noqa: BLE001
            logger.exception("director auto continuation failed project=%s", run.project_id)
            await self._pause_owned(
                run_id=run.run_id,
                username=run.username,
                project_id=run.project_id,
                reason=str(exc),
            )
            await self._notify(run, "本集自动已暂停：捏导继续执行失败，请检查服务状态后重试。")
            return False

    async def _open_ctx_store(self, ctx: ProjectContext):
        from novelvideo.api.deps import make_sqlite_store_for_context

        return await make_sqlite_store_for_context(ctx)

    async def _repair_moderation_prompt(
        self,
        *,
        run: DirectorAutoRun,
        episode: int,
        beat_num: int,
        kind: str,
        raw_error: str = "",
    ) -> PromptRepairOutcome:
        """按失败分档改写某一镜的提示词；不改词就不允许重投。"""

        ctx = run.context
        store = await self._open_ctx_store(ctx)
        try:
            try:
                return await asyncio.wait_for(
                    repair_prompt_for_moderation(
                        kind=kind,
                        store=store,
                        state_dir=ctx.state_dir,
                        project_dir=ctx.output_dir,
                        episode=episode,
                        beat_num=beat_num,
                        raw_error=raw_error,
                    ),
                    timeout=MODERATION_REPAIR_TIMEOUT_SECONDS,
                )
            except TimeoutError:
                logger.warning(
                    "审核补救改写提示词超时（第 %s 集第 %s 镜）", episode, beat_num
                )
                return PromptRepairOutcome(
                    repaired=False, kind=kind, detail="改写提示词超时"
                )
        finally:
            close = getattr(store, "close", None)
            if close:
                await close()

    async def _pause_gate(self, run: DirectorAutoRun) -> str | None:
        """Return a human-facing reason to stop, or None to keep automating.

        A project-scope run only stops for a choice it must not make on the
        user's behalf: a missing project configuration, or a missing voice
        policy once audio prerequisites become the next step. Everything else
        keeps advancing.
        """

        from novelvideo.pipeline_status import _user_has_configured, compute_pipeline_status
        from novelvideo.project_config import (
            character_images_confirmed,
            identity_images_confirmed,
        )

        ctx = run.context
        if not _user_has_configured(run.username, ctx.project_name):
            return "项目配置缺失（如视觉风格、叙事方式等），请先完成配置"
        store = await self._open_ctx_store(ctx)
        try:
            data = await compute_pipeline_status(
                store=store,
                username=run.username,
                project_name=ctx.project_name,
                project_dir=ctx.output_dir,
                ctx=ctx,
                episode=run.episode if run.episode > 0 else None,
            )
        finally:
            close = getattr(store, "close", None)
            if close:
                await close()
        next_step = str(data.get("next_step") or "")
        if next_step == "voice_setup" and not run.voice_policy:
            return VOICE_POLICY_REQUIRED_ERROR
        # 角色图片指定：给用户一次交自己图片的机会，两档都停在自己的输入之前。
        # 身份记录只在「身份规划」阶段产生，而身份规划是每集、且在肖像之后，所以
        # 身份图那一档是每集的，必须跟在身份规划之后。
        if next_step == "portraits" and not character_images_confirmed(
            run.username, ctx.project_name
        ):
            return CHARACTER_IMAGES_REQUIRED_ERROR
        if next_step == "identity_images":
            gate_episode = int(data.get("current_episode") or 0) or int(run.episode or 0)
            if gate_episode > 0 and not identity_images_confirmed(
                run.username, ctx.project_name, gate_episode
            ):
                return IDENTITY_IMAGES_REQUIRED_ERROR
        # 制作成本预估：分镜写完之后、第一批图/视频开跑之前，让用户先看到总价。
        # 这里只查配置（不跑预估），所以不会因为预估失败而卡住流水线。
        if next_step in COST_ESTIMATE_GATE_STEPS:
            from novelvideo.project_config import (
                cost_estimate_confirmed,
                cost_estimate_gate_enabled,
            )

            gate_episode = int(data.get("current_episode") or 0) or int(run.episode or 0)
            if (
                gate_episode > 0
                and cost_estimate_gate_enabled(run.username, ctx.project_name)
                and not cost_estimate_confirmed(
                    run.username, ctx.project_name, gate_episode
                )
            ):
                return COST_ESTIMATE_REQUIRED_ERROR
        return None

    async def _dispatch_stage(
        self, run: DirectorAutoRun, *, overlapped: bool = False
    ) -> tuple[bool, str | None]:
        """Deterministic fast path: enqueue the next stage directly.

        Returns ``(dispatched, signature)``. ``dispatched`` is False when the
        stage has no deterministic handler or was already attempted, so the
        caller should fall back to the agent. ``overlapped`` marks dispatches
        that went out while an earlier stage was still running (see
        ``_dispatch_overlap``); the timing log uses it to show how much of the
        pipeline actually overlapped.
        """

        from novelvideo.pipeline_auto import dispatch_next_stage

        store = await self._open_ctx_store(run.context)
        try:
            task_type, signature = await dispatch_next_stage(
                ctx=run.context,
                username=run.username,
                store=store,
                episode=run.episode,
                target_episodes=run.target_episodes,
                attempted=set(run.recovery_keys),
            )
        finally:
            close = getattr(store, "close", None)
            if close:
                await close()
        if task_type is not None:
            record_event(
                run.context.output_dir,
                "dispatch",
                stage=task_type,
                signature=signature,
                overlapped=overlapped,
            )
        return task_type is not None, signature

    async def _dispatch_overlap(self, run: DirectorAutoRun) -> bool:
        """在已有任务在飞时，把下一批已就绪的阶段也发出去（失败静默）。

        与 ``_continue_owned`` 的唯一区别是**不回退到 agent**：重叠派发是纯提速
        路径，任何异常或「暂无就绪产物」都只是「这次没重叠」，绝不能把 agent 拉进来
        改写正常流程。
        """

        if not (run.is_project_scope and run.is_deterministic):
            return False
        try:
            dispatched, signature = await self._dispatch_stage(run, overlapped=True)
        except Exception:  # noqa: BLE001
            logger.debug(
                "overlap dispatch skipped project=%s", run.project_id, exc_info=True
            )
            return False
        if not dispatched:
            return False
        if signature and signature not in run.recovery_keys:
            recorded = DirectorAutoRun(
                **{
                    **asdict(run),
                    "updated_at": _utc_now(),
                    "recovery_keys": tuple(
                        sorted({*run.recovery_keys, signature})
                    ),
                }
            )
            try:
                await self._update_owned(recorded)
            except Exception:  # noqa: BLE001
                logger.debug("overlap dispatch record failed", exc_info=True)
        return True

    async def _continue_owned(self, run: DirectorAutoRun) -> bool:
        """Advance one step: deterministic dispatch when configured, else agent."""

        if run.is_project_scope and run.is_deterministic:
            try:
                dispatched, signature = await self._dispatch_stage(run)
            except Exception:  # noqa: BLE001
                logger.exception(
                    "deterministic dispatch failed project=%s", run.project_id
                )
                dispatched, signature = False, None
            if dispatched:
                if signature and signature not in run.recovery_keys:
                    recorded = DirectorAutoRun(
                        **{
                            **asdict(run),
                            "updated_at": _utc_now(),
                            "recovery_keys": tuple(
                                sorted({*run.recovery_keys, signature})
                            ),
                        }
                    )
                    await self._update_owned(recorded)
                return True
        return await self._agent_continue(run)

    async def _next_incomplete_episode(self, run: DirectorAutoRun) -> int | None:
        from novelvideo.pipeline_status import incomplete_episodes

        ctx = run.context
        store = await self._open_ctx_store(ctx)
        try:
            episodes = incomplete_episodes(store, ctx.output_dir)
        finally:
            close = getattr(store, "close", None)
            if close:
                await close()
        if run.target_episodes and run.target_episodes > 0:
            episodes = [ep for ep in episodes if ep <= run.target_episodes]
        return episodes[0] if episodes else None

    async def _reconcile_episode_cost(self, run: DirectorAutoRun) -> None:
        """一集成片落盘后结算费用（best-effort，本地按用量 × 单价计算）。

        用本地单价表（``actual_rules`` 由真账反推，实测优先）回填 ``cost_quota``，
        **不登录上游**，因此不受中转站 429/409 影响。只写本项目 ``data.db``；失败
        绝不影响成片流程——费用报表仍可读，只是这一集的 ``cost_quota`` 还空着，
        前端会显示「结算中 / 未归因」。
        """
        try:
            from novelvideo.gateway_cost_reconcile import reconcile_local

            project_db = Path(run.context.state_dir) / "data.db"
            report = await asyncio.wait_for(
                asyncio.to_thread(
                    reconcile_local, project_db=project_db, apply=True
                ),
                timeout=EPISODE_COST_RECONCILE_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "episode cost reconcile timed out (run %s, episode %s, %.0fs)",
                run.run_id,
                run.episode,
                EPISODE_COST_RECONCILE_TIMEOUT_SECONDS,
            )
            return
        except Exception:  # noqa: BLE001 - 结算失败不阻塞成片
            logger.warning(
                "episode cost reconcile failed (run %s, episode %s)",
                run.run_id,
                run.episode,
                exc_info=True,
            )
            return
        matched = sum(table.matched for item in report.projects for table in item.tables)
        logger.info(
            "episode %s cost reconciled (run %s): source=%s matched=%s quota=%s errors=%s",
            run.episode,
            run.run_id,
            report.source,
            matched,
            report.quota,
            report.errors or "-",
        )

    def _settle_episode_points(self, run: DirectorAutoRun) -> None:
        """成片落盘后**后台**结算这一集的伴点（多退少补）。

        只做调度——真正的 relay 对账 + 补扣/退还在独立线程里跑，绝不拖慢成片、
        也不能因为结算失败而卡住客户。只有走过预扣的项目才会真的动作。
        """

        try:
            from novelvideo.points_settlement import schedule_settle

            episode = int(run.episode or 0)
            if episode <= 0:
                return
            context = run.context
            schedule_settle(
                state_dir=context.state_dir,
                episode=episode,
                projects_uuid=str(context.project_id or ""),
            )
        except Exception:  # noqa: BLE001 - 结算调度失败不影响成片
            logger.warning(
                "schedule episode points settlement failed (run %s)", run.run_id, exc_info=True
            )

    async def _run(self, run_id: str, username: str, project_id: str) -> None:
        taskless_continuations = 0
        last_overlap_at = 0.0
        busy_since: float | None = None
        while not self._stopping:
            if not await self._owns_run(run_id):
                return
            run = await asyncio.to_thread(self.store.get, username, project_id)
            if run is None or run.run_id != run_id or run.status != "running":
                return
            if run.next_attempt_at > datetime.now(timezone.utc).timestamp():
                # A retry is armed but its backoff has not elapsed yet: give the
                # upstream a moment instead of hammering it with the same request.
                await asyncio.sleep(POLL_SECONDS)
                continue
            tasks = await asyncio.to_thread(get_task_manager().list_tasks_for_project, run.context)
            relevant = _relevant_tasks(run, tasks)
            baseline = set(run.baseline_task_ids)
            handled = set(run.handled_task_ids)
            new_tasks = [task for task in relevant if task.task_id not in baseline]
            pending_new = [task for task in new_tasks if task.task_id not in handled]
            active = [task for task in pending_new if task.status in ACTIVE_STATUSES]
            if active:
                taskless_continuations = 0
                now = time.monotonic()
                if busy_since is None:
                    busy_since = now
                    record_event(run.context.output_dir, "busy_start")
                # 有任务在飞不代表必须干等：确定性调度是「按产物就绪」派发的，所以
                # 可以在旧任务跑完之前，把下一批已经就绪的活也发出去，让
                # 草图→首帧→视频→合成在时间上重叠。这是整条链路最大的一块提速：
                # 实测首帧阶段 49 次生成只花了 1.5h 计算，却铺了 10.2h 墙钟——绝大部分
                # 时间都花在「等这一阶段彻底结束才开始下一阶段」。
                if now - last_overlap_at >= OVERLAP_DISPATCH_SECONDS:
                    last_overlap_at = now
                    await self._dispatch_overlap(run)
                await asyncio.sleep(POLL_SECONDS)
                continue
            if busy_since is not None:
                record_event(
                    run.context.output_dir,
                    "busy_end",
                    duration_seconds=round(time.monotonic() - busy_since, 1),
                )
                busy_since = None

            terminal = [
                task
                for task in pending_new
                if task.status in TERMINAL_STATUSES
            ]
            if terminal:
                if not await self._owns_run(run_id):
                    return
                handled.update(task.task_id for task in terminal)
                failures = [task for task in terminal if task.status != "completed"]
                completed = [task for task in terminal if task.status == "completed"]
                # The retry budget belongs to the stage the run is driving and is
                # cleared only when the run actually moves on to another stage.
                # A completion *inside* the same stage must not clear it: for a
                # single-task stage whose completion does not satisfy the status
                # probe the dispatcher reads (something wrote less than the probe
                # looks for), clearing here would let the coordinator re-enqueue
                # the same stage forever instead of stopping after the budget.
                observed_key = str((completed or terminal)[-1].task_type or run.stage_key)
                stage_reset: dict[str, Any] = {}
                if observed_key != run.stage_key:
                    stage_reset = {
                        "stage_key": observed_key,
                        "stage_attempts": 0,
                        "next_attempt_at": 0.0,
                        "last_error": "",
                        # 真的换到下一个 stage = 真正往前，服务端自动干预的预算回满，
                        # 这样长片里偶发的多次瞬时失败不会被误判成空转。
                        "recovery_attempts": 0,
                    }
                updated = DirectorAutoRun(
                    **{
                        **asdict(run),
                        "updated_at": _utc_now(),
                        "handled_task_ids": tuple(sorted(handled)),
                        **stage_reset,
                    }
                )
                if not await self._update_owned(updated):
                    return
                if failures:
                    failed = failures[0]
                    reason = failed.error or failed.current_task or failed.status
                    reason = _failure_reason_with_detail(failed, reason)
                    if _task_is_stalled(failed):
                        # The task stopped reporting progress (idle watchdog).
                        # Treat it as an ordinary transient failure while the
                        # stage still has retry budget, and only offer the user a
                        # decision once that budget is spent.
                        if not await self._owns_run(run_id):
                            return
                        granted, attempt = await self._grant_stage_retry(
                            run=updated,
                            task=failed,
                            reason=f"卡住：{reason}",
                        )
                        if granted:
                            await self._notify(
                                updated,
                                f"{_task_instruction(failed)} 长时间没有进度更新，正在自动重试"
                                f"（第 {attempt}/{MAX_STAGE_ATTEMPTS} 次）。",
                            )
                            taskless_continuations = 0
                            await asyncio.sleep(POLL_SECONDS)
                            continue
                        await self._suspend_owned(
                            run_id=run_id,
                            username=username,
                            project_id=project_id,
                            reason=f"{STALL_REASON_TAG} {_task_label(failed)}卡住：{reason}",
                            terminal_task_id=failed.task_id,
                        )
                        await self._notify(
                            updated,
                            f"本集自动已暂停：{_task_instruction(failed)} 长时间没有进度更新，"
                            "判定为卡住。请在弹出的提示中选择重试当前步骤或终止本次自动制作。",
                        )
                        return
                    character = _missing_character_portrait(failed)
                    recovery_key = f"missing-character-portrait:{character}" if character else ""
                    if (
                        len(failures) == 1
                        and character
                        and recovery_key not in set(updated.recovery_keys)
                    ):
                        if not await self._owns_run(run_id):
                            return
                        recovering = DirectorAutoRun(
                            **{
                                **asdict(updated),
                                "updated_at": _utc_now(),
                                "recovery_keys": tuple(
                                    sorted({*updated.recovery_keys, recovery_key})
                                ),
                            }
                        )
                        if not await self._update_owned(recovering):
                            return
                        await self._notify(
                            recovering,
                            f"检测到 {_task_instruction(failed)} 缺少前置肖像，"
                            f"正在自动补生成「{character}」肖像。",
                        )
                        if not await self._owns_run(run_id):
                            return
                        wrote = await self._agent_continue(
                            recovering,
                            instruction=(
                                f"自动修复第 {run.episode} 集身份图前置条件：失败信息明确指出角色"
                                f"「{character}」缺少 Portrait（面部特写）。请只读确认后，仅启动该角色"
                                "的一个 Portrait 生成任务；不要重试身份图，不要启动其他步骤，不要询问用户确认。"
                            ),
                        )
                        if wrote:
                            taskless_continuations = 0
                            await asyncio.sleep(POLL_SECONDS)
                            continue
                        latest = await asyncio.to_thread(self.store.get, username, project_id)
                        if latest is None or latest.status != "running":
                            return
                        await self._pause_owned(
                            run_id=run_id,
                            username=username,
                            project_id=project_id,
                            reason=f"无法自动补生成「{character}」肖像",
                            terminal_task_id=failed.task_id,
                        )
                        await self._notify(
                            recovering,
                            f"本集自动已暂停：未能启动「{character}」肖像生成，请检查角色肖像配置。",
                        )
                        return
                    moderation_kind = _moderation_kind(failed)
                    if moderation_kind is not None:
                        # 内容审核失败：不允许拿同一套参数再投一次（同一段提示词必然
                        # 再被拒）。先改提示词，改得出来才重投一次；改不出来就停下，
                        # 把决定权交回用户。
                        if not await self._owns_run(run_id):
                            return
                        target = _moderation_repair_target(failed, updated)
                        repair_key = (
                            moderation_repair_recovery_key(*target) if target else ""
                        )
                        if not target:
                            # 连「是哪一镜」都定位不到（批量 stage 的失败报文没有镜号）：
                            # 无法本地降级，只能把决定权交回用户。用 awaiting_confirmation
                            # 而不是 paused，避免客户端把这类暂停当硬暂停无限续跑。
                            await self._suspend_owned(
                                run_id=run_id,
                                username=username,
                                project_id=project_id,
                                reason="内容审核未通过，无法定位到具体镜头，需要人工处理",
                                terminal_task_id=failed.task_id,
                            )
                            await self._notify(
                                updated,
                                f"本集自动已暂停：{_task_instruction(failed)} "
                                "未通过内容审核，且无法定位到具体镜头，"
                                "请检查提示词或参考素材后重试。",
                            )
                            return
                        if repair_key in set(updated.recovery_keys):
                            # 已自动改写过一次仍被拒：改用本地降级、跳过该镜继续，
                            # 不再把整条 run 停死（否则用户只会看到「一直在制作中」）。
                            stage_key = _stage_key_for(failed, updated)
                            blocked_run = await self._block_shot_and_continue(
                                run=updated,
                                episode=target[0],
                                beat_num=target[1],
                                stage=stage_key,
                                code=CONTENT_MODERATION_FAILED_CODE,
                                reason="内容审核未通过，已自动改写过一次提示词仍未通过",
                                kind=_fallback_kind(stage_key),
                            )
                            if blocked_run is None:
                                return
                            await self._notify(
                                blocked_run,
                                f"{_task_instruction(failed)} 已自动改写过一次提示词，"
                                "仍未通过内容审核；已用本地素材降级该镜，先保证本集完整，"
                                "稍后可在工作台修改提示词重做该镜。",
                            )
                            taskless_continuations = 0
                            await asyncio.sleep(POLL_SECONDS)
                            continue
                        outcome = await self._repair_moderation_prompt(
                            run=updated,
                            episode=target[0],
                            beat_num=target[1],
                            kind=moderation_kind,
                            raw_error=_task_moderation_text(failed),
                        )
                        if not outcome.repaired:
                            stage_key = _stage_key_for(failed, updated)
                            blocked_run = await self._block_shot_and_continue(
                                run=updated,
                                episode=target[0],
                                beat_num=target[1],
                                stage=stage_key,
                                code=CONTENT_MODERATION_FAILED_CODE,
                                reason=(
                                    f"内容审核未通过且无法改写提示词（{outcome.detail}）"
                                ),
                                kind=_fallback_kind(stage_key),
                            )
                            if blocked_run is None:
                                return
                            await self._notify(
                                blocked_run,
                                f"{_task_instruction(failed)} 未通过内容审核，"
                                f"且无法自动改写提示词（{outcome.detail}）；"
                                "已用本地素材降级该镜，先保证本集完整，"
                                "稍后可在工作台修改提示词重做该镜。",
                            )
                            taskless_continuations = 0
                            await asyncio.sleep(POLL_SECONDS)
                            continue
                        repaired_run = DirectorAutoRun(
                            **{
                                **asdict(updated),
                                "updated_at": _utc_now(),
                                # 清掉 dispatch 签名才能让这个 stage 重新入队，
                                # 同时把「已改过一次词」记进 recovery key。
                                "recovery_keys": tuple(
                                    sorted(
                                        {
                                            *self._clear_stage_signatures(updated),
                                            repair_key,
                                        }
                                    )
                                ),
                                "next_attempt_at": datetime.now(
                                    timezone.utc
                                ).timestamp()
                                + _stage_retry_delay(1),
                                "last_error": (
                                    f"{RETRY_REASON_PREFIX}1/1] "
                                    f"内容审核未通过：{outcome.detail}"
                                ),
                            }
                        )
                        if not await self._update_owned(repaired_run):
                            return
                        await self._notify(
                            repaired_run,
                            f"{_task_instruction(failed)} 未通过内容审核"
                            f"（{outcome.kind_label}）。{outcome.detail}，正在重试一次。",
                        )
                        taskless_continuations = 0
                        await asyncio.sleep(POLL_SECONDS)
                        continue
                    fatal = _is_fatal_failure(failed)
                    if fatal:
                        # Billing/permission/cancellation: a retry cannot change
                        # the outcome, so stop instead of burning the budget.
                        await self._pause_owned(
                            run_id=run_id,
                            username=username,
                            project_id=project_id,
                            reason=_failure_reason_with_detail(failed, fatal),
                            terminal_task_id=failed.task_id,
                            kind=PAUSE_KIND_FATAL,
                        )
                        await self._notify(
                            updated,
                            f"本集自动已暂停：{_task_instruction(failed)} 失败，{fatal}，无需自动重试。",
                        )
                        return
                    granted, attempt = await self._grant_stage_retry(
                        run=updated,
                        task=failed,
                        reason=reason,
                    )
                    if granted:
                        await self._notify(
                            updated,
                            f"{_task_instruction(failed)} 执行失败，正在自动重试"
                            f"（第 {attempt}/{MAX_STAGE_ATTEMPTS} 次）。",
                        )
                        taskless_continuations = 0
                        await asyncio.sleep(POLL_SECONDS)
                        continue
                    # 重试预算用尽：若这一失败能定位到具体镜头、且该 stage 有可靠的
                    # 本地兜底，就降级该镜并继续推进（工作台不允许因一镜停死）。
                    shot = _moderation_repair_target(failed, updated)
                    fallback_kind = _fallback_kind(_stage_key_for(failed, updated))
                    if shot is not None and fallback_kind != "none":
                        blocked_run = await self._block_shot_and_continue(
                            run=updated,
                            episode=shot[0],
                            beat_num=shot[1],
                            stage=_stage_key_for(failed, updated),
                            code="retries_exhausted",
                            reason=(
                                f"自动重试 "
                                f"{max(0, min(attempt - 1, MAX_STAGE_ATTEMPTS))} 次仍未成功："
                                f"{reason}"
                            ),
                            kind=fallback_kind,
                        )
                        if blocked_run is None:
                            return
                        await self._notify(
                            blocked_run,
                            f"{_task_instruction(failed)} 自动重试仍未成功；"
                            "已用本地素材降级该镜，先保证本集完整，"
                            "稍后可在工作台重做该镜。",
                        )
                        taskless_continuations = 0
                        await asyncio.sleep(POLL_SECONDS)
                        continue
                    await self._pause_owned(
                        run_id=run_id,
                        username=username,
                        project_id=project_id,
                        reason=reason,
                        terminal_task_id=failed.task_id,
                    )
                    await self._notify(
                        updated,
                        f"本集自动已暂停：{_task_instruction(failed)} "
                        f"{('已取消' if failed.status == 'cancelled' else '失败')}，{reason}。"
                        f"（已自动重试 {max(0, min(attempt - 1, MAX_STAGE_ATTEMPTS))} 次仍未成功）",
                    )
                    return
                compose = next((task for task in terminal if task.task_type == "compose_episode"), None)
                if len(terminal) == 1:
                    summary = f"✅ {_task_instruction(terminal[0])} 已完成。"
                else:
                    summary = f"✅ 本批 {len(terminal)} 个任务已完成。"
                if compose is not None:
                    await self._notify(updated, f"{summary}正在展示第 {run.episode} 集成片。")
                    # 成片落盘后立刻按本地捏驿账单结算这一集的费用，用户不用点任何
                    # 按钮就能在本集卡片上看到金额明细。
                    await self._reconcile_episode_cost(updated)
                    self._settle_episode_points(updated)
                    if updated.is_project_scope:
                        next_episode = await self._next_incomplete_episode(updated)
                        if next_episode is not None:
                            advanced = DirectorAutoRun(
                                **{
                                    **asdict(updated),
                                    "episode": next_episode,
                                    "updated_at": _utc_now(),
                                }
                            )
                            if not await self._update_owned(advanced):
                                return
                            await self._notify(
                                advanced,
                                f"第 {run.episode} 集已完成，成片自动继续制作第 {next_episode} 集。",
                            )
                            if not await self._owns_run(run_id):
                                return
                            await self._continue_owned(advanced)
                            taskless_continuations = 0
                            await asyncio.sleep(POLL_SECONDS)
                            continue
                    if not await self._owns_run(run_id):
                        return
                    await self._agent_continue(updated, final_delivery=True)
                    if not await self._owns_run(run_id):
                        return
                    completed = DirectorAutoRun(
                        **{**asdict(updated), "status": "completed", "updated_at": _utc_now()}
                    )
                    if not await self._update_owned(completed):
                        return
                    await self._broadcast_status(completed)
                    return
                if updated.is_project_scope:
                    pause_reason = await self._pause_gate(updated)
                    if pause_reason:
                        if not await self._owns_run(run_id):
                            return
                        await self._pause_owned(
                            run_id=run_id,
                            username=username,
                            project_id=project_id,
                            reason=pause_reason,
                        )
                        await self._notify(
                            updated,
                            f"自动成片已暂停：{_pause_reason_display(pause_reason)}。",
                        )
                        return
                auto_label = "自动成片" if updated.is_project_scope else "本集自动"
                await self._notify(updated, f"{summary}{auto_label}正在继续下一步。")
                if not await self._owns_run(run_id):
                    return
                await self._continue_owned(updated)
                # Deliberately *not* resetting ``taskless_continuations`` here: a
                # task can complete without moving the stage along (its output did
                # not satisfy the status probe the dispatcher reads). Keeping the
                # counter makes the taskless budget below the backstop for that,
                # so the run pauses after the retry budget instead of re-enqueuing
                # the same stage forever. It is cleared as soon as any task is
                # actually running (see the ``active`` branch above).
                await asyncio.sleep(POLL_SECONDS)
                continue

            activated_age = max(0.0, datetime.now(timezone.utc).timestamp() - _timestamp(run.activated_at))
            if not pending_new and activated_age >= INITIAL_GRACE_SECONDS:
                if chat_service.chat_run_lock_is_active(username, project_id):
                    await asyncio.sleep(POLL_SECONDS)
                    continue
                # A taskless continuation is often transient: the agent may have
                # spent the turn on reads (or on a route that 404s) before it
                # could start the step. Retry within a bounded budget and only
                # then pause the durable run for the user's decision.
                if taskless_continuations >= MAX_TASKLESS_CONTINUATIONS:
                    # 空转也会停在必须由用户拍板的闸门上：缺声线策略、肖像/身份图
                    # 时确定性派发不会产生写任务。若这里只报「未产生写任务」，前端
                    # 认不出闸门类型、弹不出对应卡片，客户点「继续制作」只会再空转
                    # 一轮（2026-11 现场：nn_1103_3 停在 voice_setup 反复空转）。
                    # 所以耗尽空转预算时先问一次闸门，命中就按闸门原因暂停。
                    if run.is_project_scope:
                        try:
                            gate_reason = await self._pause_gate(run)
                        except Exception:  # noqa: BLE001 - 闸门识别失败不能拖垮续跑
                            logger.exception(
                                "taskless pause gate check failed (run %s)", run.run_id
                            )
                            gate_reason = None
                        if gate_reason:
                            if not await self._owns_run(run_id):
                                return
                            await self._pause_owned(
                                run_id=run_id,
                                username=username,
                                project_id=project_id,
                                reason=gate_reason,
                            )
                            await self._notify(
                                run,
                                f"自动成片已暂停：{_pause_reason_display(gate_reason)}。",
                            )
                            return
                    wrote, note = self._last_continuation(run_id)
                    reason = (
                        "自动续跑未产生新的任务"
                        if wrote
                        else "自动续跑未产生写任务"
                    )
                    if note:
                        reason = f"{reason}（最后一次工具调用：{note}）"
                    retried_from = _retry_pause_detail(run)
                    if retried_from:
                        reason = f"{reason}；最后失败原因：{retried_from}"
                    granted, attempt = await self._grant_stage_retry(
                        run=run,
                        task=None,
                        reason=reason,
                    )
                    if granted:
                        await self._notify(
                            run,
                            f"自动续跑连续几轮没有产生新任务，正在重新驱动"
                            f"（第 {attempt}/{MAX_STAGE_ATTEMPTS} 次）。",
                        )
                        taskless_continuations = 0
                        await asyncio.sleep(POLL_SECONDS)
                        continue
                    await self._pause_owned(
                        run_id=run_id,
                        username=username,
                        project_id=project_id,
                        reason=reason,
                    )
                    await self._notify(
                        run,
                        "本集自动已暂停：捏导连续几轮没有产生新的生成任务，"
                        "请检查当前前置条件后重试。",
                    )
                    return
                taskless_continuations += 1
                if not await self._owns_run(run_id):
                    return
                await self._continue_owned(run)
                await asyncio.sleep(POLL_SECONDS)
                continue
            await asyncio.sleep(POLL_SECONDS)


coordinator = DirectorAutoCoordinator()
